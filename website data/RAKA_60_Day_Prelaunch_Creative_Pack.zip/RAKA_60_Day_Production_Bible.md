# RAKA FIRST CIRCLE — 60-DAY ORGANIC CONTENT PRODUCTION BIBLE
**Dates:** October 10–December 8, 2026 (Asia/Karachi)  |  **Deliverables:** 60 static visuals, 240 carousel-image prompts, 60 ten-second video prompts.
## Creative rules for every asset
- No products, bottles, packaging, formula, ingredients-as-product reveal, fake testimonials, medical or dermatological advice, guaranteed results or before/after pictures.
- Use RAKA supplied logo as a design layer. Never ask AI to invent a logo or typeset exact words inside images.
- Static and carousel: 1080 × 1350 portrait; video: 1080 × 1920, exactly 10 seconds. Subtitles added in editing.
- Video 0–3s: attention; 3–7s: clear learning; 7–10s: nuance and a single CTA. The CTA often remains visual rather than spoken to fit the duration.
- Education first, then brand storytelling and First Circle signup. No invented clinical claims, medical studies or certification endorsements.
- SEO keywords are **editorial search-intent hypotheses**, not verified keyword-volume rankings. Validate them in Search Console and keyword tools after launch.
- Distinguish **shedding** (hair released) and **breakage** (hair shaft snaps), and avoid implying any one sign diagnoses a cause.
- Noise impacts well-being/sleep; do NOT claim traffic noise directly causes hair loss. Junk food and poultry are NOT proven individual hair-loss causes.

## Pakistan-specific evidence and responsible messaging

| Topic | Evidence strength | Safe message for RAKA | Avoid saying |
|---|---|---|---|
| Smog/airborne particles | Pakistan's exposure: high-confidence monitoring; direct hair-loss outcome: emerging | Particles may settle on hair/scalp; keep cleansing routines gentle and personal | Smog directly makes everyone lose hair; an oil removes PM2.5 damage |
| Hard water | Mixed individual studies; 2025 meta-analysis points to possible lower hair-fibre tensile strength | Water hardness may influence hair feel and breakage; evidence remains limited in real-world settings | All tap water causes baldness; water filters restore hair |
| Shared tools and towels | Clear hygiene guidance from CDC | Don't share brushes, combs or towels; keep personal tools clean | Every shared brush transmits an infection |
| Food variety and nutrient adequacy | Established role for dietary insufficiency in some hair problems | Overall food variety and enough nutrition matter | A burger or a poultry meal directly causes hair fall |
| Broiler chicken hormones | Pakistani veterinary university rejects routine growth-hormone rumour | No sound evidence that ordinary broiler meat causes hair loss via injected growth hormones | All poultry is unsafe or all farms have identical practices |
| Road noise | Recognized effects on rest and well-being; direct hair-loss causation unproven | Busy surroundings may affect sleep and stress; treat hair claims separately | Traffic horns cause balding |
| Wet hair, heat, tension, rough towel drying | Good professional guidance on avoidable physical damage | Gentler handling may help reduce breakage | Hair already split or damaged can be repaired permanently by oil |

**Research anchors:** IQAir 2025; CDC WASH guidance; AAD public guidance; WHO environmental-noise guidance; UNICEF Pakistan National Nutrition Survey; a 2018 Pakistan hard-water experiment; a 2025 hard-water systematic review; UVAS poultry FAQs. URLs are supplied in the evidence register and the daily prompts.

## Audience, SEO, and publishing direction

- **Audience:** Urban and peri-urban adults in Pakistan; women and men 18+, with inclusive visuals for different natural hair textures and styles. Use Karachi, Lahore and Islamabad settings when location serves the scene; never imply a city-wide hazard reading on a particular day without a current source.
- **SEO clusters:** *hair breakage vs hair fall*, *smog and hair care*, *hard water hair Pakistan*, *sharing hair brush hygiene*, *towel rubbing wet hair*, *balanced diet hair health*, *broiler chicken hair loss myth*, and *RAKA First Circle*. These are topic ideas, not verified search-volume figures.
- **Publishing:** Record one 10-second master per day and export native clean files to TikTok, Instagram/Facebook Reels, YouTube Shorts, Snapchat Spotlight where suitable. Publish the 4-slide carousel to Instagram/Facebook and a redesigned graphic or Pin to Pinterest. Repurpose headlines into question posts for Threads, X, and community channels.
- **Post workflow:** Fact-check copy → create image scenes without AI-generated lettering → overlay legible copy/logo manually → check claim guardrails and inclusivity → localize captions into natural English or Roman Urdu when appropriate → publish → review weekly saves, qualified profile visits, site visits, and confirmed First Circle signups.
- **On-screen safe area:** Keep key content away from the top 15% and bottom 20% of 9:16 frames; check inside each app before publishing because UI overlays vary.
- **CTA strategy:** Days 1–35 mostly save/share/learn; days 36–49 discuss/vote; days 50–60 direct registration at `raka.pk/first-circle`. Never describe the waitlist as scarce unless it genuinely is.
- **No hidden product reveal:** No bottles, silhouettes shaped like bottles, caps, labels, formula showcases, mysterious oil pours, before-after imagery, or synthetic user testimonials. Product names can appear as editorial text during Week 7 and countdown.

## Evidence register
- **AIR:** IQAir World Air Quality Report, Pakistan 2025 — https://www.iqair.com/world-most-polluted-countries
- **POLL:** Review: The Invisible Threat to Hair and Scalp from Air Pollution — https://doi.org/10.15244/pjoes/188036
- **WATER:** 2025 systematic review/meta-analysis on hard water and hair — https://doi.org/10.4103/ijt.ijt_86_25
- **WATER_PK:** Pakistan hair tensile-strength study — https://pubmed.ncbi.nlm.nih.gov/30034190/
- **CDC:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html
- **AAD:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips
- **DAMAGE:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage
- **NUTRI:** AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips
- **UVAS:** University of Veterinary and Animal Sciences: Poultry myths — https://www.uvas.edu.pk/advisory_service/PAS/faqs.php
- **NOISE:** WHO: Environmental noise and health — https://www.who.int/europe/news-room/fact-sheets/item/noise
- **PAKNUT:** UNICEF Pakistan: National Nutrition Survey 2018 — https://www.unicef.org/pakistan/national-nutrition-survey-2018
- **BRAND:** Brand communication concept; no external factual claim

---

## DAY 01 — 2026-10-10 — Every Hair Story Deserves Attention
**Week 1 / Introducing RAKA & hair-care awareness**  |  **SEO query hypothesis:** hair care routine Pakistan  |  **CTA:** Follow RAKA

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Natural dark hair strands swirling through black air against soft gold light. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your Hair Has a Story”. Optional small overlay: “Follow RAKA”.

**Carousel slide 1 — Overlay:** Your Hair Has a Story

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Natural dark hair strands swirling through black air against soft gold light. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your Hair Has a Story”.

**Carousel slide 2 — Overlay:** Not Every Story Is the Same

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Four elegant cropped portraits showing varied Pakistani hair textures and lengths. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Not Every Story Is the Same”.

**Carousel slide 3 — Overlay:** Start with Understanding

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: A notebook beside a wide-tooth comb and neutral linen, no product containers. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Start with Understanding”.

**Carousel slide 4 — Overlay:** Welcome to RAKA

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Abstract mountain ridge in gold dusk, lots of negative space. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Welcome to RAKA”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Dark hair waves reveal texture; on-screen title “Your Hair Has a Story”. 00:03–00:07: Four honest hair portraits crossfade; overlay “Not Every Story Is the Same”. 00:07–00:10: Golden ridge appears and RAKA logo fades in; overlay “Welcome to RAKA” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Every hair story is different. RAKA begins with understanding, not promises.”. END CTA: “Follow RAKA”.

**Suggested caption:** Every Hair Story Deserves Attention — Every hair story is different. RAKA begins with understanding, not promises. Follow RAKA. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No performance claims or synthetic before/after comparisons. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 02 — 2026-10-11 — Hair Fall and Breakage Are Not Identical
**Week 1 / Introducing RAKA & hair-care awareness**  |  **SEO query hypothesis:** hair fall vs hair breakage  |  **CTA:** Save this comparison

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Single full-length strand and short snapped strands on cream background. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Hair Fall ≠ Breakage”. Optional small overlay: “Save this comparison”.

**Carousel slide 1 — Overlay:** Hair Fall ≠ Breakage

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single full-length strand and short snapped strands on cream background. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Fall ≠ Breakage”.

**Carousel slide 2 — Overlay:** Shedding: A Hair Cycle Process

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal close crop of loose long strands on clean wooden comb. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Shedding: A Hair Cycle Process”.

**Carousel slide 3 — Overlay:** Breakage: The Strand Snaps

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Macro of a short uneven snapped hair strand with subtle highlight. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Breakage: The Strand Snaps”.

**Carousel slide 4 — Overlay:** Observe Before You Assume

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Person carefully checking hair in daylight, dignified natural expression. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Observe Before You Assume”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Long strand drifts into shot; on-screen title “Hair Fall ≠ Breakage”. 00:03–00:07: Short broken piece appears side-by-side; overlay “Shedding: A Hair Cycle Process”. 00:07–00:10: Split card ends with Observe, don’t assume; overlay “Observe Before You Assume” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Shedding and breakage are different. Understanding the difference can help you rethink your routine.”. END CTA: “Save this comparison”.

**Suggested caption:** Hair Fall and Breakage Are Not Identical — Shedding and breakage are different. Understanding the difference can help you rethink your routine. Save this comparison. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Cannot diagnose reason by viewing a strand alone. **Source IDs:** DAMAGE

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 03 — 2026-10-12 — Your City Is Part of Your Routine
**Week 1 / Introducing RAKA & hair-care awareness**  |  **SEO query hypothesis:** Pakistan air pollution hair care  |  **CTA:** Learn with RAKA

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Editorial Lahore street commute from above with soft atmospheric haze. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your Environment Matters”. Optional small overlay: “Learn with RAKA”.

**Carousel slide 1 — Overlay:** Your Environment Matters

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Editorial Lahore street commute from above with soft atmospheric haze. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your Environment Matters”.

**Carousel slide 2 — Overlay:** Dust Meets Daily Life

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Macro backlit dust particles floating near dark hair, not penetrating follicles. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Dust Meets Daily Life”.

**Carousel slide 3 — Overlay:** Hair Collects Daily Residue

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Closeup of hair near a soft windblown urban window. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Collects Daily Residue”.

**Carousel slide 4 — Overlay:** Routines Can Adapt

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Person gently cleansing hair at home, face not required. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Routines Can Adapt”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Hazy city commute and floating specks; on-screen title “Your Environment Matters”. 00:03–00:07: Cut to hair movement by a window; overlay “Dust Meets Daily Life”. 00:07–00:10: Clean calm bathroom scene and title; overlay “Routines Can Adapt” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “City air adds to daily exposure. Thoughtful cleansing and gentle care belong in the conversation.”. END CTA: “Learn with RAKA”.

**Suggested caption:** Your City Is Part of Your Routine — City air adds to daily exposure. Thoughtful cleansing and gentle care belong in the conversation. Learn with RAKA. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid asserting pollution directly causes an individual person’s hair loss. **Source IDs:** AIR,POLL,CDC

**Supporting references:** IQAir World Air Quality Report, Pakistan 2025 — https://www.iqair.com/world-most-polluted-countries; Review: The Invisible Threat to Hair and Scalp from Air Pollution — https://doi.org/10.15244/pjoes/188036; CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html

---

## DAY 04 — 2026-10-13 — The Little Habits Add Up
**Week 1 / Introducing RAKA & hair-care awareness**  |  **SEO query hypothesis:** daily hair habits for less breakage  |  **CTA:** Save the routine

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Flat-lay of clean wide-tooth comb, soft towel and soft fabric scrunchie. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Small Habits, Big Difference”. Optional small overlay: “Save the routine”.

**Carousel slide 1 — Overlay:** Small Habits, Big Difference

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Flat-lay of clean wide-tooth comb, soft towel and soft fabric scrunchie. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Small Habits, Big Difference”.

**Carousel slide 2 — Overlay:** Handle Wet Hair Gently

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close crop of damp dark hair lightly wrapped in a soft towel. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Handle Wet Hair Gently”.

**Carousel slide 3 — Overlay:** Ease the Tension

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Loose low hairstyle with fabric scrunchie against warm light. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Ease the Tension”.

**Carousel slide 4 — Overlay:** Keep Learning

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal lined paper with three neat checkboxes and no rendered words. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Keep Learning”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Towel rubbed roughly then motion freezes; on-screen title “Small Habits, Big Difference”. 00:03–00:07: Hands gently blot damp hair; overlay “Handle Wet Hair Gently”. 00:07–00:10: Loose scrunchie and Save this habit overlay; overlay “Keep Learning” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Gentler drying, styling, and detangling can help limit avoidable hair breakage.”. END CTA: “Save the routine”.

**Suggested caption:** The Little Habits Add Up — Gentler drying, styling, and detangling can help limit avoidable hair breakage. Save the routine. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Describe reduced avoidable breakage, not guaranteed growth. **Source IDs:** DAMAGE,AAD

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 05 — 2026-10-14 — Your Scalp Is Skin Too
**Week 1 / Introducing RAKA & hair-care awareness**  |  **SEO query hypothesis:** scalp hygiene Pakistan  |  **CTA:** Comment your routine

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Tasteful macro of clean hair parting under diffused light. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Let’s Talk About Scalp Care”. Optional small overlay: “Comment your routine”.

**Carousel slide 1 — Overlay:** Let’s Talk About Scalp Care

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Tasteful macro of clean hair parting under diffused light. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Let’s Talk About Scalp Care”.

**Carousel slide 2 — Overlay:** Oil and Sweat Can Build Up

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Illustration-style external droplets on scalp surface, not infection depiction. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Oil and Sweat Can Build Up”.

**Carousel slide 3 — Overlay:** So Can Product Residue

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Beauty-free flat lay of water droplets and comb, no cosmetics bottles. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “So Can Product Residue”.

**Carousel slide 4 — Overlay:** Build a Suitable Routine

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Soft bathroom steam and folded personal towel. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Build a Suitable Routine”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Scalp parting emerges from shadow; on-screen title “Let’s Talk About Scalp Care”. 00:03–00:07: Abstract sweat and residue icons move over surface; overlay “Oil and Sweat Can Build Up”. 00:07–00:10: Towel and simple routine card closes; overlay “Build a Suitable Routine” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Your scalp has everyday needs too. The right routine depends on your own hair and scalp.”. END CTA: “Comment your routine”.

**Suggested caption:** Your Scalp Is Skin Too — Your scalp has everyday needs too. The right routine depends on your own hair and scalp. Comment your routine. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No scalp diagnosis or promises to eliminate dandruff. **Source IDs:** CDC,AAD

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 06 — 2026-10-15 — One Size Never Fits Every Hair
**Week 1 / Introducing RAKA & hair-care awareness**  |  **SEO query hypothesis:** different hair types Pakistan  |  **CTA:** Vote on your hair type

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Three portrait panels with straight, wavy and curly Pakistani hair. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Different Hair. Different Needs.”. Optional small overlay: “Vote on your hair type”.

**Carousel slide 1 — Overlay:** Different Hair. Different Needs.

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Three portrait panels with straight, wavy and curly Pakistani hair. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Different Hair. Different Needs.”.

**Carousel slide 2 — Overlay:** What Works Can Vary

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Macro of distinct hair textures with consistent neutral light. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “What Works Can Vary”.

**Carousel slide 3 — Overlay:** Watch How Hair Responds

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hands gently detangling wavy hair with wide-tooth comb. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Watch How Hair Responds”.

**Carousel slide 4 — Overlay:** Choose Thoughtfully

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal abstract texture gradients and three balanced circles. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Choose Thoughtfully”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Three hair textures enter one by one; on-screen title “Different Hair. Different Needs.”. 00:03–00:07: Tight shot of wide-tooth comb gliding gently; overlay “What Works Can Vary”. 00:07–00:10: Text: Care should fit you; overlay “Choose Thoughtfully” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Straight, wavy, or curly: hair care works best when the routine fits the person.”. END CTA: “Vote on your hair type”.

**Suggested caption:** One Size Never Fits Every Hair — Straight, wavy, or curly: hair care works best when the routine fits the person. Vote on your hair type. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid ranking one type as healthier or implying hair typing is diagnostic. **Source IDs:** AAD

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 07 — 2026-10-16 — The First Circle Starts Here
**Week 1 / Introducing RAKA & hair-care awareness**  |  **SEO query hypothesis:** RAKA First Circle early access  |  **CTA:** Join First Circle

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Gold circle of light on black, premium minimal mood. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “An Invitation Before the Reveal”. Optional small overlay: “Join First Circle”.

**Carousel slide 1 — Overlay:** An Invitation Before the Reveal

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gold circle of light on black, premium minimal mood. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “An Invitation Before the Reveal”.

**Carousel slide 2 — Overlay:** Learn About Your Hair

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open book pages, natural hair strands, no bottles. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Learn About Your Hair”.

**Carousel slide 3 — Overlay:** Get a Practical Hair-Care Guide

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Seven blank elegant paper cards fanned together. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Get a Practical Hair-Care Guide”.

**Carousel slide 4 — Overlay:** Be First to Hear From RAKA

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Architectural gold doorway of light and subtle mountain silhouette. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Be First to Hear From RAKA”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Fine gold circular line draws on black; on-screen title “An Invitation Before the Reveal”. 00:03–00:07: Pages turn toward warm morning light; overlay “Learn About Your Hair”. 00:07–00:10: Circle opens as raka.pk/first-circle CTA appears; overlay “Be First to Hear From RAKA” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Before we reveal our collection, join a circle built around better hair-care knowledge.”. END CTA: “Join First Circle”.

**Suggested caption:** The First Circle Starts Here — Before we reveal our collection, join a circle built around better hair-care knowledge. Join First Circle. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not imply limited seats or discounts unless real. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 08 — 2026-10-17 — Not Every Hair in Your Brush Signals Trouble
**Week 2 / Understanding shedding & breakage**  |  **SEO query hypothesis:** hair shedding hairbrush facts  |  **CTA:** Save and share

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: A clean dark hairbrush holding a few natural loose strands. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “What Your Hairbrush Can Tell You”. Optional small overlay: “Save and share”.

**Carousel slide 1 — Overlay:** What Your Hairbrush Can Tell You

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: A clean dark hairbrush holding a few natural loose strands. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “What Your Hairbrush Can Tell You”.

**Carousel slide 2 — Overlay:** Shedding Happens as Hair Cycles

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Soft abstract lifecycle arcs without scientific numeric claims. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Shedding Happens as Hair Cycles”.

**Carousel slide 3 — Overlay:** Breakage Looks Different

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Macro cutaway of visibly shorter snapped ends beside long strands. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Breakage Looks Different”.

**Carousel slide 4 — Overlay:** Look at the Full Picture

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hand placing comb down next to journal. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Look at the Full Picture”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Brush enters frame against cream; on-screen title “What Your Hairbrush Can Tell You”. 00:03–00:07: Macro long strands versus short pieces; overlay “Shedding Happens as Hair Cycles”. 00:07–00:10: Journal closes: Learn, don’t guess; overlay “Look at the Full Picture” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “A few loose strands can be normal. Brush contents alone cannot explain hair loss.”. END CTA: “Save and share”.

**Suggested caption:** Not Every Hair in Your Brush Signals Trouble — A few loose strands can be normal. Brush contents alone cannot explain hair loss. Save and share. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No diagnosis or numerical daily-loss thresholds. **Source IDs:** DAMAGE,NUTRI

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage; AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips

---

## DAY 09 — 2026-10-18 — What Is Hair Breakage?
**Week 2 / Understanding shedding & breakage**  |  **SEO query hypothesis:** hair breakage causes Pakistan  |  **CTA:** Save the tips

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Single hair fiber snapped in macro abstract editorial style. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “When a Strand Snaps”. Optional small overlay: “Save the tips”.

**Carousel slide 1 — Overlay:** When a Strand Snaps

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single hair fiber snapped in macro abstract editorial style. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “When a Strand Snaps”.

**Carousel slide 2 — Overlay:** Friction Can Add Stress

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fabric seam lightly rubbing a hair section close-up. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Friction Can Add Stress”.

**Carousel slide 3 — Overlay:** So Can High Heat

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hairdryer held away from dark hair, stylized heat shimmer. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “So Can High Heat”.

**Carousel slide 4 — Overlay:** Choose Gentler Handling

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Loose braid and soft comb photographed naturally. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Choose Gentler Handling”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Macro intact strand becomes a short piece; on-screen title “When a Strand Snaps”. 00:03–00:07: Fast cuts friction cloth and heat shimmer; overlay “Friction Can Add Stress”. 00:07–00:10: Soft comb glides and line: Gentle is smart; overlay “Choose Gentler Handling” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Rough friction and excessive heat can weaken strands. A gentler routine is worth trying.”. END CTA: “Save the tips”.

**Suggested caption:** What Is Hair Breakage? — Rough friction and excessive heat can weaken strands. A gentler routine is worth trying. Save the tips. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No implication breakage equals follicular hair loss. **Source IDs:** DAMAGE

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 10 — 2026-10-19 — Smog Season and Your Hair
**Week 2 / Understanding shedding & breakage**  |  **SEO query hypothesis:** Lahore smog hair routine  |  **CTA:** Save for smog season

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Authentic Lahore morning skyline in soft grey atmosphere. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Smog Season Changes the Day”. Optional small overlay: “Save for smog season”.

**Carousel slide 1 — Overlay:** Smog Season Changes the Day

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Authentic Lahore morning skyline in soft grey atmosphere. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Smog Season Changes the Day”.

**Carousel slide 2 — Overlay:** Airborne Particles Are Real

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Floating particulate graphics above city; purely conceptual. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Airborne Particles Are Real”.

**Carousel slide 3 — Overlay:** Residue Can Settle Outdoors

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Backlit strands after city commute, no dirty-hair shaming. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Residue Can Settle Outdoors”.

**Carousel slide 4 — Overlay:** Keep Cleansing Practical

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Neutral bathroom scene, folded cloth and water. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Keep Cleansing Practical”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Lahore smog skyline shot; on-screen title “Smog Season Changes the Day”. 00:03–00:07: Particulate overlays glide over hair surface; overlay “Airborne Particles Are Real”. 00:07–00:10: Calm wash-space transition: Rethink routines; overlay “Keep Cleansing Practical” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Smog is an environmental concern. Keep daily hair care practical, gentle, and personal.”. END CTA: “Save for smog season”.

**Suggested caption:** Smog Season and Your Hair — Smog is an environmental concern. Keep daily hair care practical, gentle, and personal. Save for smog season. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid single-city current AQI predictions and miracle detox terms. **Source IDs:** AIR,POLL,CDC

**Supporting references:** IQAir World Air Quality Report, Pakistan 2025 — https://www.iqair.com/world-most-polluted-countries; Review: The Invisible Threat to Hair and Scalp from Air Pollution — https://doi.org/10.15244/pjoes/188036; CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html

---

## DAY 11 — 2026-10-20 — Are Split Ends the Same as Hair Fall?
**Week 2 / Understanding shedding & breakage**  |  **SEO query hypothesis:** split ends vs hair fall  |  **CTA:** Share with a friend

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Split-tip hair shaft shown as realistic macro render. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Split Ends ≠ Shedding”. Optional small overlay: “Share with a friend”.

**Carousel slide 1 — Overlay:** Split Ends ≠ Shedding

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Split-tip hair shaft shown as realistic macro render. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Split Ends ≠ Shedding”.

**Carousel slide 2 — Overlay:** The End of a Strand Can Fray

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Soft hair ends in backlight, tasteful realism. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “The End of a Strand Can Fray”.

**Carousel slide 3 — Overlay:** A Root Is a Different Part

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hair roots depicted only as simple abstract educational diagram. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “A Root Is a Different Part”.

**Carousel slide 4 — Overlay:** Protect the Length You Have

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Silky natural hair section with neat ends. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Protect the Length You Have”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Macro frayed hair tip appears; on-screen title “Split Ends ≠ Shedding”. 00:03–00:07: Vertical wipe into loose full strand; overlay “The End of a Strand Can Fray”. 00:07–00:10: Text: Different concerns; different questions; overlay “Protect the Length You Have” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Frayed ends and hair shedding describe different things. Start by knowing what you mean.”. END CTA: “Share with a friend”.

**Suggested caption:** Are Split Ends the Same as Hair Fall? — Frayed ends and hair shedding describe different things. Start by knowing what you mean. Share with a friend. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Never say an oil can permanently repair split ends. **Source IDs:** DAMAGE

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 12 — 2026-10-21 — The Tight Hairstyle Check
**Week 2 / Understanding shedding & breakage**  |  **SEO query hypothesis:** tight hairstyles breakage  |  **CTA:** Try the style check

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Elegant high-tension ponytail silhouette represented without pain. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Does Your Hairstyle Pull?”. Optional small overlay: “Try the style check”.

**Carousel slide 1 — Overlay:** Does Your Hairstyle Pull?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Elegant high-tension ponytail silhouette represented without pain. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Does Your Hairstyle Pull?”.

**Carousel slide 2 — Overlay:** Repeated Tension Matters

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close-up of stretched hair tie in fingers. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Repeated Tension Matters”.

**Carousel slide 3 — Overlay:** Looser Can Be Kinder

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Soft low ponytail tied with fabric scrunchie. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Looser Can Be Kinder”.

**Carousel slide 4 — Overlay:** Switch Up Your Style

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Three comfortable hairstyle sketches in gold outline. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Switch Up Your Style”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Tight hair elastic stretches into shot; on-screen title “Does Your Hairstyle Pull?”. 00:03–00:07: Cut to relaxed scrunchie and loose style; overlay “Repeated Tension Matters”. 00:07–00:10: Text: Less pull, more comfort; overlay “Switch Up Your Style” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “A hairstyle should not need constant pulling. Try comfortable, looser options where possible.”. END CTA: “Try the style check”.

**Suggested caption:** The Tight Hairstyle Check — A hairstyle should not need constant pulling. Try comfortable, looser options where possible. Try the style check. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid individual diagnosis of traction alopecia. **Source IDs:** DAMAGE

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 13 — 2026-10-22 — Your Hair and the Weather
**Week 2 / Understanding shedding & breakage**  |  **SEO query hypothesis:** humidity frizz hair Pakistan  |  **CTA:** Tell us your city

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Humid city scene window condensation, natural loose flyaways. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Why Does Hair Feel Different Outside?”. Optional small overlay: “Tell us your city”.

**Carousel slide 1 — Overlay:** Why Does Hair Feel Different Outside?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Humid city scene window condensation, natural loose flyaways. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Why Does Hair Feel Different Outside?”.

**Carousel slide 2 — Overlay:** Humidity Can Change Hair Feel

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Macro curls and straight strands in soft moist air. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Humidity Can Change Hair Feel”.

**Carousel slide 3 — Overlay:** Friction Makes Styling Harder

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close-up hair brushing against a scarf edge. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Friction Makes Styling Harder”.

**Carousel slide 4 — Overlay:** Respond Without Fighting Texture

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Person with natural waves outside in soft light. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Respond Without Fighting Texture”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Window fog and hair in slow motion; on-screen title “Why Does Hair Feel Different Outside?”. 00:03–00:07: Light frizz visual, no alarming damage filter; overlay “Humidity Can Change Hair Feel”. 00:07–00:10: Text: Adjust, don’t overdo; overlay “Respond Without Fighting Texture” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Humidity can change how hair looks and feels. Work with your texture, not against it.”. END CTA: “Tell us your city”.

**Suggested caption:** Your Hair and the Weather — Humidity can change how hair looks and feels. Work with your texture, not against it. Tell us your city. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No claim humidity itself makes follicles stop growing. **Source IDs:** AAD

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 14 — 2026-10-23 — Week Two: What Did You Notice?
**Week 2 / Understanding shedding & breakage**  |  **SEO query hypothesis:** hair shedding routine checklist  |  **CTA:** Comment a question

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Paper checklist on sleek black desk. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your Hair-Care Observation List”. Optional small overlay: “Comment a question”.

**Carousel slide 1 — Overlay:** Your Hair-Care Observation List

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Paper checklist on sleek black desk. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your Hair-Care Observation List”.

**Carousel slide 2 — Overlay:** Breakage or Shedding?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two gentle line-art examples, one long and one snapped strand. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Breakage or Shedding?”.

**Carousel slide 3 — Overlay:** Friction or Tension?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fabric and scrunchie side by side. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Friction or Tension?”.

**Carousel slide 4 — Overlay:** Questions Welcome

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gold question mark formed with hair-thin line. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Questions Welcome”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Cards marked Strand, Friction, Tension shuffle; on-screen title “Your Hair-Care Observation List”. 00:03–00:07: Hand circles one observation; overlay “Breakage or Shedding?”. 00:07–00:10: CTA: Share a question with RAKA; overlay “Questions Welcome” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “You do not need to guess your way through hair care. Which topic should we explain next?”. END CTA: “Comment a question”.

**Suggested caption:** Week Two: What Did You Notice? — You do not need to guess your way through hair care. Which topic should we explain next? Comment a question. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Questions should not request sensitive medical history. **Source IDs:** DAMAGE,AAD

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 15 — 2026-10-24 — What Builds Up on a Scalp?
**Week 3 / Scalp care, water & hygiene**  |  **SEO query hypothesis:** scalp buildup sweat pollution  |  **CTA:** Save the explainer

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Tasteful dark hair part under macro light. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Scalp Buildup, Simplified”. Optional small overlay: “Save the explainer”.

**Carousel slide 1 — Overlay:** Scalp Buildup, Simplified

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Tasteful dark hair part under macro light. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Scalp Buildup, Simplified”.

**Carousel slide 2 — Overlay:** Natural Oil Is Normal

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Golden abstract droplets sitting on surface of hair strands. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Natural Oil Is Normal”.

**Carousel slide 3 — Overlay:** Sweat and Residue Vary

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Abstract surface particles and soft water reflections. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Sweat and Residue Vary”.

**Carousel slide 4 — Overlay:** A Clean Routine Is Personal

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fresh personal towel near clean water sink. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “A Clean Routine Is Personal”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Macro scalp part focus pulls in; on-screen title “Scalp Buildup, Simplified”. 00:03–00:07: Three minimalist icons: oil, sweat, residue; overlay “Natural Oil Is Normal”. 00:07–00:10: Soft water rinse concludes; overlay “A Clean Routine Is Personal” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Natural oils, sweat, and residue vary from person to person. Cleansing needs vary too.”. END CTA: “Save the explainer”.

**Suggested caption:** What Builds Up on a Scalp? — Natural oils, sweat, and residue vary from person to person. Cleansing needs vary too. Save the explainer. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not label normal sebum toxic. **Source IDs:** CDC,AAD

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 16 — 2026-10-25 — Dry Scalp and Dandruff Are Not the Same Claim
**Week 3 / Scalp care, water & hygiene**  |  **SEO query hypothesis:** dry scalp vs dandruff difference  |  **CTA:** Save this distinction

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: White flakes against dark hair represented as abstract dots. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Flakes Can Mean Different Things”. Optional small overlay: “Save this distinction”.

**Carousel slide 1 — Overlay:** Flakes Can Mean Different Things

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: White flakes against dark hair represented as abstract dots. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Flakes Can Mean Different Things”.

**Carousel slide 2 — Overlay:** Dryness Is One Possibility

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Stylized parched cracked surface not actual human scalp. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Dryness Is One Possibility”.

**Carousel slide 3 — Overlay:** Not Every Flake Has One Cause

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two side-by-side ambiguous scalp-themed silhouettes. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Not Every Flake Has One Cause”.

**Carousel slide 4 — Overlay:** Avoid Self-Labeling

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Thoughtful portrait checking hair in mirror. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Avoid Self-Labeling”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Tiny white abstract flakes fade in; on-screen title “Flakes Can Mean Different Things”. 00:03–00:07: Question mark splits into two arrows; overlay “Dryness Is One Possibility”. 00:07–00:10: Text: One symptom, many possibilities; overlay “Avoid Self-Labeling” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Flakes have more than one possible explanation. Avoid assuming every flake means dryness.”. END CTA: “Save this distinction”.

**Suggested caption:** Dry Scalp and Dandruff Are Not the Same Claim — Flakes have more than one possible explanation. Avoid assuming every flake means dryness. Save this distinction. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No diagnosis, treatment recommendation or claim an oil treats dandruff. **Source IDs:** CDC,AAD

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 17 — 2026-10-26 — Tap Water: What Does Hard Mean?
**Week 3 / Scalp care, water & hygiene**  |  **SEO query hypothesis:** hard water hair Pakistan  |  **CTA:** Save and learn

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Clear running tap, mineral-inspired line elements. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Hard Water: A Real Term”. Optional small overlay: “Save and learn”.

**Carousel slide 1 — Overlay:** Hard Water: A Real Term

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Clear running tap, mineral-inspired line elements. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Hard Water: A Real Term”.

**Carousel slide 2 — Overlay:** Minerals Vary by Supply

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Calcium and magnesium represented as restrained colored spheres. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Minerals Vary by Supply”.

**Carousel slide 3 — Overlay:** Hair Feel May Be Affected

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hair strand with mineral deposits depicted conceptually, not photographically. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Feel May Be Affected”.

**Carousel slide 4 — Overlay:** Evidence Is Still Developing

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Clean graphic scale balancing two research-paper icons. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Evidence Is Still Developing”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Water trickles from tap in slow motion; on-screen title “Hard Water: A Real Term”. 00:03–00:07: Mineral spheres overlay frame; overlay “Minerals Vary by Supply”. 00:07–00:10: Text: Learn the difference, skip myths; overlay “Evidence Is Still Developing” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Hard water contains dissolved minerals. Research on effects on hair is still developing.”. END CTA: “Save and learn”.

**Suggested caption:** Tap Water: What Does Hard Mean? — Hard water contains dissolved minerals. Research on effects on hair is still developing. Save and learn. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No claim that all Pakistani tap water causes baldness. **Source IDs:** WATER,WATER_PK

**Supporting references:** 2025 systematic review/meta-analysis on hard water and hair — https://doi.org/10.4103/ijt.ijt_86_25; Pakistan hair tensile-strength study — https://pubmed.ncbi.nlm.nih.gov/30034190/

---

## DAY 18 — 2026-10-27 — The Shared Hairbrush Habit
**Week 3 / Scalp care, water & hygiene**  |  **SEO query hypothesis:** sharing hairbrush hygiene  |  **CTA:** Share with family

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Two hands reaching toward a single neutral brush. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “One Brush. How Many People?”. Optional small overlay: “Share with family”.

**Carousel slide 1 — Overlay:** One Brush. How Many People?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two hands reaching toward a single neutral brush. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “One Brush. How Many People?”.

**Carousel slide 2 — Overlay:** Personal Items Stay Personal

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Individual neatly labeled combs by abstract colors, no text in image. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Personal Items Stay Personal”.

**Carousel slide 3 — Overlay:** Clean Tools Matter

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Person removing trapped strands from clean brush. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Clean Tools Matter”.

**Carousel slide 4 — Overlay:** An Easy Household Rule

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Separate brushes arranged for a family. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “An Easy Household Rule”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Two hands reach for one brush; on-screen title “One Brush. How Many People?”. 00:03–00:07: Cut to two separate brushes neatly arranged; overlay “Personal Items Stay Personal”. 00:07–00:10: Title: Keep yours personal; overlay “An Easy Household Rule” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Shared brushes can pass more than tangles. Keeping personal tools separate is a simple hygiene habit.”. END CTA: “Share with family”.

**Suggested caption:** The Shared Hairbrush Habit — Shared brushes can pass more than tangles. Keeping personal tools separate is a simple hygiene habit. Share with family. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid alleging all shared brushes cause fungal illness. **Source IDs:** CDC

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html

---

## DAY 19 — 2026-10-28 — Do You Share a Towel?
**Week 3 / Scalp care, water & hygiene**  |  **SEO query hypothesis:** sharing towels hair scalp hygiene  |  **CTA:** Save the reminder

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Two neutral folded towels with different thread textures. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your Towel, Your Routine”. Optional small overlay: “Save the reminder”.

**Carousel slide 1 — Overlay:** Your Towel, Your Routine

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two neutral folded towels with different thread textures. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your Towel, Your Routine”.

**Carousel slide 2 — Overlay:** Shared Damp Items Are Avoidable

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single damp towel draped on communal rail, tasteful neutral aesthetic. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Shared Damp Items Are Avoidable”.

**Carousel slide 3 — Overlay:** Dry and Store Separately

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fresh towel hanging separately in bright, ventilated room. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Dry and Store Separately”.

**Carousel slide 4 — Overlay:** Small Habits Count

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Family bathroom hooks each holding separate folded towel. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Small Habits Count”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Shared hanging towel enters shot; on-screen title “Your Towel, Your Routine”. 00:03–00:07: Hands separate and hang two clean towels; overlay “Shared Damp Items Are Avoidable”. 00:07–00:10: Text: One small hygiene habit; overlay “Small Habits Count” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Your towel is a personal-care item. Use your own clean one and let it dry properly.”. END CTA: “Save the reminder”.

**Suggested caption:** Do You Share a Towel? — Your towel is a personal-care item. Use your own clean one and let it dry properly. Save the reminder. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No infection statistics or household shame. **Source IDs:** CDC

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html

---

## DAY 20 — 2026-10-29 — What About the Scalp After a Dusty Commute?
**Week 3 / Scalp care, water & hygiene**  |  **SEO query hypothesis:** dusty commute hair wash routine  |  **CTA:** Tell us your commute habit

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Pakistani commuter viewed from behind on dusty roadside with modest clothing. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “A Day Outside Leaves Traces”. Optional small overlay: “Tell us your commute habit”.

**Carousel slide 1 — Overlay:** A Day Outside Leaves Traces

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Pakistani commuter viewed from behind on dusty roadside with modest clothing. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “A Day Outside Leaves Traces”.

**Carousel slide 2 — Overlay:** Sweat, Oil and Dust Can Mix

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Abstract floating micro specks settling on outer hair. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Sweat, Oil and Dust Can Mix”.

**Carousel slide 3 — Overlay:** Clean According to Your Needs

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Water rinsing a hand against hair silhouette. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Clean According to Your Needs”.

**Carousel slide 4 — Overlay:** Gentle Works Better Than Harsh

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Soft towel wrapping wet ends. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Gentle Works Better Than Harsh”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Urban commute street pan; on-screen title “A Day Outside Leaves Traces”. 00:03–00:07: Dust motes crossfade into bathroom tiles; overlay “Sweat, Oil and Dust Can Mix”. 00:07–00:10: Close on gently folded towel; overlay “Gentle Works Better Than Harsh” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “After busy outdoor days, choose a cleansing routine that suits your scalp and hair.”. END CTA: “Tell us your commute habit”.

**Suggested caption:** What About the Scalp After a Dusty Commute? — After busy outdoor days, choose a cleansing routine that suits your scalp and hair. Tell us your commute habit. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not require daily washing for everyone. **Source IDs:** AIR,CDC,AAD

**Supporting references:** IQAir World Air Quality Report, Pakistan 2025 — https://www.iqair.com/world-most-polluted-countries; CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 21 — 2026-10-30 — The Scalp-Care Quiz
**Week 3 / Scalp care, water & hygiene**  |  **SEO query hypothesis:** scalp hygiene quiz  |  **CTA:** Take the First Circle quiz

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Gold framed blank quiz card against warm charcoal. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “What Describes Your Routine?”. Optional small overlay: “Take the First Circle quiz”.

**Carousel slide 1 — Overlay:** What Describes Your Routine?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gold framed blank quiz card against warm charcoal. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “What Describes Your Routine?”.

**Carousel slide 2 — Overlay:** Wash When It Feels Oily?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Neatly arranged clean water and brush in bath setting. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Wash When It Feels Oily?”.

**Carousel slide 3 — Overlay:** Notice Product Residue?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal layered abstract translucent films. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Notice Product Residue?”.

**Carousel slide 4 — Overlay:** Your Routine Is Yours

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Confident Pakistani person with natural hair and gentle expression. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Your Routine Is Yours”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Three quick question cards flip; on-screen title “What Describes Your Routine?”. 00:03–00:07: Hands select an option on abstract mobile interface; overlay “Wash When It Feels Oily?”. 00:07–00:10: Text: Take the RAKA routine quiz; overlay “Your Routine Is Yours” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Scalp care is personal. Answer a few simple routine questions and learn more.”. END CTA: “Take the First Circle quiz”.

**Suggested caption:** The Scalp-Care Quiz — Scalp care is personal. Answer a few simple routine questions and learn more. Take the First Circle quiz. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** This is a non-diagnostic questionnaire; avoid collecting medical details. **Source IDs:** CDC,AAD

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 22 — 2026-10-31 — The Towel-Rubbing Myth
**Week 4 / Everyday damage-reducing habits**  |  **SEO query hypothesis:** towel rubbing wet hair damage  |  **CTA:** Save this habit

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Hands rubbing damp ends against coarse cloth, shown as an illustrative freeze frame. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Stop the Towel Tug”. Optional small overlay: “Save this habit”.

**Carousel slide 1 — Overlay:** Stop the Towel Tug

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hands rubbing damp ends against coarse cloth, shown as an illustrative freeze frame. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Stop the Towel Tug”.

**Carousel slide 2 — Overlay:** Wet Strands Need Care

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fine water droplets along hair strands in macro. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Wet Strands Need Care”.

**Carousel slide 3 — Overlay:** Blot. Wrap. Be Gentle.

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hands gently pressing a soft towel around hair ends. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Blot. Wrap. Be Gentle.”.

**Carousel slide 4 — Overlay:** A Small Swap to Try

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Clean cotton t-shirt and microfiber towel folded side by side. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “A Small Swap to Try”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Rough towel motion freezes abruptly; on-screen title “Stop the Towel Tug”. 00:03–00:07: Soft cotton wrap replaces rubbing; overlay “Wet Strands Need Care”. 00:07–00:10: Text: Blot, do not scrub; overlay “A Small Swap to Try” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Rough towel rubbing can encourage breakage. Gentle blotting is a simple alternative.”. END CTA: “Save this habit”.

**Suggested caption:** The Towel-Rubbing Myth — Rough towel rubbing can encourage breakage. Gentle blotting is a simple alternative. Save this habit. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Never claim hair heals once damaged. **Source IDs:** DAMAGE,AAD

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 23 — 2026-11-01 — Detangle Without the Tug-of-War
**Week 4 / Everyday damage-reducing habits**  |  **SEO query hypothesis:** detangle hair without breakage  |  **CTA:** Save the technique

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Close-up natural tangled dark hair against cream backdrop. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Why Force a Knot?”. Optional small overlay: “Save the technique”.

**Carousel slide 1 — Overlay:** Why Force a Knot?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close-up natural tangled dark hair against cream backdrop. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Why Force a Knot?”.

**Carousel slide 2 — Overlay:** Start at the Ends

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hands carefully separating hair tips without pulling. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Start at the Ends”.

**Carousel slide 3 — Overlay:** Use a Wide-Tooth Comb

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single premium wooden wide-tooth comb on linen. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Use a Wide-Tooth Comb”.

**Carousel slide 4 — Overlay:** Work Up Slowly

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gentle comb sequence shown as three subtle positions. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Work Up Slowly”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Knot shown without distressed subject; on-screen title “Why Force a Knot?”. 00:03–00:07: Hands gently work from ends upward; overlay “Start at the Ends”. 00:07–00:10: Comb rests on cream cloth and title; overlay “Work Up Slowly” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Ease through knots instead of pulling. The right approach also depends on hair texture.”. END CTA: “Save the technique”.

**Suggested caption:** Detangle Without the Tug-of-War — Ease through knots instead of pulling. The right approach also depends on hair texture. Save the technique. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** For tightly curled hair, damp detangling can be appropriate. **Source IDs:** AAD,DAMAGE

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips; AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 24 — 2026-11-02 — How Much Heat Is Too Much?
**Week 4 / Everyday damage-reducing habits**  |  **SEO query hypothesis:** heat styling hair breakage  |  **CTA:** Share this reminder

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Close-up unplugged straightener reflecting warm studio light. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Heat Is a Styling Trade-Off”. Optional small overlay: “Share this reminder”.

**Carousel slide 1 — Overlay:** Heat Is a Styling Trade-Off

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close-up unplugged straightener reflecting warm studio light. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Heat Is a Styling Trade-Off”.

**Carousel slide 2 — Overlay:** Repeated High Heat Adds Stress

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Subtle red heat glow near loose strands, symbolic only. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Repeated High Heat Adds Stress”.

**Carousel slide 3 — Overlay:** Lower Heat, Less Often

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Styling tool resting away from natural hair. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Lower Heat, Less Often”.

**Carousel slide 4 — Overlay:** Natural Texture Deserves Space

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Portrait embracing waves and curls with no editing of frizz. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Natural Texture Deserves Space”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Warm heat glow on styling tool; on-screen title “Heat Is a Styling Trade-Off”. 00:03–00:07: Switch moves from high to low; overlay “Repeated High Heat Adds Stress”. 00:07–00:10: Natural hair flows, Text: Less heat when you can; overlay “Natural Texture Deserves Space” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Frequent high heat can damage strands. Lower heat and fewer passes are worth considering.”. END CTA: “Share this reminder”.

**Suggested caption:** How Much Heat Is Too Much? — Frequent high heat can damage strands. Lower heat and fewer passes are worth considering. Share this reminder. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid saying a particular temperature guarantees safety. **Source IDs:** DAMAGE,AAD

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 25 — 2026-11-03 — Hair Ties Matter
**Week 4 / Everyday damage-reducing habits**  |  **SEO query hypothesis:** hair ties hair breakage  |  **CTA:** Try a gentler style

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Close-up stretched elastic band held between fingers. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Is Your Hair Tie Too Tight?”. Optional small overlay: “Try a gentler style”.

**Carousel slide 1 — Overlay:** Is Your Hair Tie Too Tight?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close-up stretched elastic band held between fingers. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Is Your Hair Tie Too Tight?”.

**Carousel slide 2 — Overlay:** Tight Pulling Can Strain Hair

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Stylized strand tension line illustration, no scalp injury. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Tight Pulling Can Strain Hair”.

**Carousel slide 3 — Overlay:** Try Softer Options

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Three fabric scrunchies on clean stone. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Try Softer Options”.

**Carousel slide 4 — Overlay:** Comfort Is a Good Cue

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Loose braid worn comfortably by Pakistani model. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Comfort Is a Good Cue”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Elastic snaps slightly in slow motion not toward person; on-screen title “Is Your Hair Tie Too Tight?”. 00:03–00:07: Fabric scrunchie slides into frame; overlay “Tight Pulling Can Strain Hair”. 00:07–00:10: Loose braid with overlay: Ease the tension; overlay “Comfort Is a Good Cue” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Consider switching tight elastics for softer styles when your hair feels pulled.”. END CTA: “Try a gentler style”.

**Suggested caption:** Hair Ties Matter — Consider switching tight elastics for softer styles when your hair feels pulled. Try a gentler style. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No claim scrunchies prevent genetic hair loss. **Source IDs:** DAMAGE

**Supporting references:** AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 26 — 2026-11-04 — Wash the Scalp, Not the Length Aggressively
**Week 4 / Everyday damage-reducing habits**  |  **SEO query hypothesis:** how to shampoo scalp gently  |  **CTA:** Save wash-day tip

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Gentle shower water flowing over dark hair, no product containers. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Where Should Shampoo Go?”. Optional small overlay: “Save wash-day tip”.

**Carousel slide 1 — Overlay:** Where Should Shampoo Go?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gentle shower water flowing over dark hair, no product containers. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Where Should Shampoo Go?”.

**Carousel slide 2 — Overlay:** Focus on the Scalp

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hands lightly moving at hair roots without thick foam. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Focus on the Scalp”.

**Carousel slide 3 — Overlay:** Let Rinse Water Flow

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Clean water travelling down length of hair. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Let Rinse Water Flow”.

**Carousel slide 4 — Overlay:** Condition for Manageability

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Managed natural hair ends resting on neutral towel. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Condition for Manageability”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Fingers gently circle at scalp; on-screen title “Where Should Shampoo Go?”. 00:03–00:07: Water runs over hair length in close-up; overlay “Focus on the Scalp”. 00:07–00:10: Card: Gentle routine, not harsh scrubbing; overlay “Condition for Manageability” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Focus cleansing on the scalp and avoid rough scrubbing through the length.”. END CTA: “Save wash-day tip”.

**Suggested caption:** Wash the Scalp, Not the Length Aggressively — Focus cleansing on the scalp and avoid rough scrubbing through the length. Save wash-day tip. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No particular commercial product recommended. **Source IDs:** AAD,DAMAGE

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips; AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 27 — 2026-11-05 — Could Your Tap Water Change Hair Feel?
**Week 4 / Everyday damage-reducing habits**  |  **SEO query hypothesis:** hard water hair feel Pakistan  |  **CTA:** Explore the evidence

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Split city-inspired illustrations of two household taps. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your Tap Water Is Not the Same Everywhere”. Optional small overlay: “Explore the evidence”.

**Carousel slide 1 — Overlay:** Your Tap Water Is Not the Same Everywhere

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Split city-inspired illustrations of two household taps. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your Tap Water Is Not the Same Everywhere”.

**Carousel slide 2 — Overlay:** Hardness Comes from Minerals

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Simple calcium-magnesium spheres suspended in clear water. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Hardness Comes from Minerals”.

**Carousel slide 3 — Overlay:** Studies Do Not All Agree

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two neutral research papers arranged side by side. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Studies Do Not All Agree”.

**Carousel slide 4 — Overlay:** Notice Your Routine, Not Fear

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hands carefully handling damp hair in soft light. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Notice Your Routine, Not Fear”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Two tap streams split screen; on-screen title “Your Tap Water Is Not the Same Everywhere”. 00:03–00:07: Minerals form abstract dots; question mark appears; overlay “Hardness Comes from Minerals”. 00:07–00:10: Text: Evidence first, fear never; overlay “Notice Your Routine, Not Fear” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Minerals in water may influence how hair feels. Research is mixed, so avoid quick conclusions.”. END CTA: “Explore the evidence”.

**Suggested caption:** Could Your Tap Water Change Hair Feel? — Minerals in water may influence how hair feels. Research is mixed, so avoid quick conclusions. Explore the evidence. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not insist water filters fix hair loss. **Source IDs:** WATER,WATER_PK

**Supporting references:** 2025 systematic review/meta-analysis on hard water and hair — https://doi.org/10.4103/ijt.ijt_86_25; Pakistan hair tensile-strength study — https://pubmed.ncbi.nlm.nih.gov/30034190/

---

## DAY 28 — 2026-11-06 — Weekend Routine Reset
**Week 4 / Everyday damage-reducing habits**  |  **SEO query hypothesis:** weekly hair care checklist  |  **CTA:** Download the free checklist

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Open paper checklist with blank boxes and fine gold lines. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your 5-Minute Routine Reset”. Optional small overlay: “Download the free checklist”.

**Carousel slide 1 — Overlay:** Your 5-Minute Routine Reset

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open paper checklist with blank boxes and fine gold lines. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your 5-Minute Routine Reset”.

**Carousel slide 2 — Overlay:** Clean Your Personal Tools

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hands removing strands from a personal comb. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Clean Your Personal Tools”.

**Carousel slide 3 — Overlay:** Check Towel Habits

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fresh towels folded in ventilated wardrobe. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Check Towel Habits”.

**Carousel slide 4 — Overlay:** Plan a Gentle Wash

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Warm daylight on tidy bath setting, no product bottles. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Plan a Gentle Wash”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Quick cuts comb, towel, hair tie; on-screen title “Your 5-Minute Routine Reset”. 00:03–00:07: Three simple visual checkmarks pop in; overlay “Clean Your Personal Tools”. 00:07–00:10: Text: Small routines feel easier; overlay “Plan a Gentle Wash” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Clean tools, gentle drying, comfortable styling. Pick one habit to improve this week.”. END CTA: “Download the free checklist”.

**Suggested caption:** Weekend Routine Reset — Clean tools, gentle drying, comfortable styling. Pick one habit to improve this week. Download the free checklist. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** A checklist not a treatment protocol. **Source IDs:** CDC,AAD,DAMAGE

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips; AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 29 — 2026-11-07 — Why the Name RAKA?
**Week 5 / RAKA story, standards & considered living**  |  **SEO query hypothesis:** RAKA Rakaposhi inspired brand  |  **CTA:** Follow the journey

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Cinematic northern Pakistan peak in early morning natural golden light. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Inspired by Rakaposhi”. Optional small overlay: “Follow the journey”.

**Carousel slide 1 — Overlay:** Inspired by Rakaposhi

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Cinematic northern Pakistan peak in early morning natural golden light. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Inspired by Rakaposhi”.

**Carousel slide 2 — Overlay:** Strength Without Noise

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close-up weathered mountain stone and cloud shadow. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Strength Without Noise”.

**Carousel slide 3 — Overlay:** Details Matter

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Premium typography workspace with gold foil sample, no packaging. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Details Matter”.

**Carousel slide 4 — Overlay:** RAKA: A Considered Approach

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Abstract black-gold ridge contours with spacious composition. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “RAKA: A Considered Approach”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Mountain emerges through cloud; on-screen title “Inspired by Rakaposhi”. 00:03–00:07: Gold lines trace gentle ridgeline; overlay “Strength Without Noise”. 00:07–00:10: RAKA logo reveal centered on black; overlay “RAKA: A Considered Approach” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Inspired by Rakaposhi, RAKA values clarity, care, and a considered approach.”. END CTA: “Follow the journey”.

**Suggested caption:** Why the Name RAKA? — Inspired by Rakaposhi, RAKA values clarity, care, and a considered approach. Follow the journey. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not imply ingredients are sourced from the mountain. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 30 — 2026-11-08 — The Quiet Side of Self-Care
**Week 5 / RAKA story, standards & considered living**  |  **SEO query hypothesis:** traffic noise stress sleep hair myths  |  **CTA:** Save the perspective

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Pakistani city road seen behind double-glazed window, no unsafe driving. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Busy City, Quiet Moment”. Optional small overlay: “Save the perspective”.

**Carousel slide 1 — Overlay:** Busy City, Quiet Moment

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Pakistani city road seen behind double-glazed window, no unsafe driving. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Busy City, Quiet Moment”.

**Carousel slide 2 — Overlay:** Noise Can Affect Rest

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Soft sound-wave graphic against evening skyline. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Noise Can Affect Rest”.

**Carousel slide 3 — Overlay:** Good Rest Supports Well-Being

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Calm bedroom scene with warm lamp and closed curtains. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Good Rest Supports Well-Being”.

**Carousel slide 4 — Overlay:** Not a Hair-Loss Diagnosis

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Journal, tea cup and serene early morning window. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Not a Hair-Loss Diagnosis”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Traffic sounds visible as thin waveforms; on-screen title “Busy City, Quiet Moment”. 00:03–00:07: Door closes to quiet bedroom; overlay “Noise Can Affect Rest”. 00:07–00:10: Text: Rest matters; no hair-loss shortcuts; overlay “Not a Hair-Loss Diagnosis” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Traffic noise can affect rest. That does not prove it directly causes hair loss.”. END CTA: “Save the perspective”.

**Suggested caption:** The Quiet Side of Self-Care — Traffic noise can affect rest. That does not prove it directly causes hair loss. Save the perspective. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Never claim sound causes balding or relaxing regrows hair. **Source IDs:** NOISE

**Supporting references:** WHO: Environmental noise and health — https://www.who.int/europe/news-room/fact-sheets/item/noise

---

## DAY 31 — 2026-11-09 — Care Without Grand Promises
**Week 5 / RAKA story, standards & considered living**  |  **SEO query hypothesis:** honest hair care brand Pakistan  |  **CTA:** Join the conversation

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Minimal off-white editorial typography canvas, subtle gold corner lines. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Better Questions. Fewer Claims.”. Optional small overlay: “Join the conversation”.

**Carousel slide 1 — Overlay:** Better Questions. Fewer Claims.

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal off-white editorial typography canvas, subtle gold corner lines. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Better Questions. Fewer Claims.”.

**Carousel slide 2 — Overlay:** What Do We Actually Know?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Blank open research notebook and reading glasses, no fake documents. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “What Do We Actually Know?”.

**Carousel slide 3 — Overlay:** What Still Needs Evidence?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two abstract circles labelled conceptually by future design overlay. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “What Still Needs Evidence?”.

**Carousel slide 4 — Overlay:** RAKA Believes in Clarity

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single gold line rising gently across black frame. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “RAKA Believes in Clarity”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Large question mark fades into research paper; on-screen title “Better Questions. Fewer Claims.”. 00:03–00:07: Gold line traces a simple underline; overlay “What Do We Actually Know?”. 00:07–00:10: Text: Clarity over hype; overlay “RAKA Believes in Clarity” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Hair care deserves useful information, not overnight promises.”. END CTA: “Join the conversation”.

**Suggested caption:** Care Without Grand Promises — Hair care deserves useful information, not overnight promises. Join the conversation. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not assert clinical evidence that is not held. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 32 — 2026-11-10 — A Routine That Fits Real Life
**Week 5 / RAKA story, standards & considered living**  |  **SEO query hypothesis:** busy Pakistani lifestyle hair routine  |  **CTA:** Tell us your biggest obstacle

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Pakistani young professional getting ready by window. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “For Busy Real Life”. Optional small overlay: “Tell us your biggest obstacle”.

**Carousel slide 1 — Overlay:** For Busy Real Life

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Pakistani young professional getting ready by window. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “For Busy Real Life”.

**Carousel slide 2 — Overlay:** Travel. Work. Family.

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Three tasteful lifestyle vignettes: commute, laptop, family dinner. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Travel. Work. Family.”.

**Carousel slide 3 — Overlay:** Make Care Manageable

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Comb and towel neatly placed in small drawer. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Make Care Manageable”.

**Carousel slide 4 — Overlay:** Simple Is Sustainable

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Person stepping outdoors confidently with natural hair. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Simple Is Sustainable”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Fast montage commute, work, evening; on-screen title “For Busy Real Life”. 00:03–00:07: Pause on one tidy hair-care drawer; overlay “Travel. Work. Family.”. 00:07–00:10: Text: Start with what fits; overlay “Simple Is Sustainable” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “The best everyday routine is one you can realistically maintain.”. END CTA: “Tell us your biggest obstacle”.

**Suggested caption:** A Routine That Fits Real Life — The best everyday routine is one you can realistically maintain. Tell us your biggest obstacle. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid behavior shaming or efficacy claims. **Source IDs:** BRAND,AAD

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 33 — 2026-11-11 — What Does Quality Mean to You?
**Week 5 / RAKA story, standards & considered living**  |  **SEO query hypothesis:** premium hair care quality Pakistan  |  **CTA:** Comment what quality means

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Closeup of carefully stitched linen and gold light, no products. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Quality Is in the Questions”. Optional small overlay: “Comment what quality means”.

**Carousel slide 1 — Overlay:** Quality Is in the Questions

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Closeup of carefully stitched linen and gold light, no products. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Quality Is in the Questions”.

**Carousel slide 2 — Overlay:** Clarity of Information

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Tidy empty label-composition grid without bottle or label art. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Clarity of Information”.

**Carousel slide 3 — Overlay:** Care in Communication

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open notebook with highlighted neutral lines. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Care in Communication”.

**Carousel slide 4 — Overlay:** Respect for Your Choice

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Warm portrait looking confidently toward camera. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Respect for Your Choice”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Light glides across abstract materials; on-screen title “Quality Is in the Questions”. 00:03–00:07: Research notes turn in soft light; overlay “Clarity of Information”. 00:07–00:10: Text: Quality begins with questions; overlay “Respect for Your Choice” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “We believe premium care should include clear information and thoughtful choices.”. END CTA: “Comment what quality means”.

**Suggested caption:** What Does Quality Mean to You? — We believe premium care should include clear information and thoughtful choices. Comment what quality means. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid reference to manufacturer or unverified certifications. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 34 — 2026-11-12 — The Difference Between a Habit and a Hype
**Week 5 / RAKA story, standards & considered living**  |  **SEO query hypothesis:** viral hair trends myth  |  **CTA:** Save this thought

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Split-screen fast social-feed inspired abstract tiles, no brands. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Trend or Thoughtful Habit?”. Optional small overlay: “Save this thought”.

**Carousel slide 1 — Overlay:** Trend or Thoughtful Habit?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Split-screen fast social-feed inspired abstract tiles, no brands. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Trend or Thoughtful Habit?”.

**Carousel slide 2 — Overlay:** Trends Move Fast

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fast flipping neutral smartphone silhouettes. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Trends Move Fast”.

**Carousel slide 3 — Overlay:** Basic Care Still Matters

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Combs, scrunchie and personal towel arranged thoughtfully. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Basic Care Still Matters”.

**Carousel slide 4 — Overlay:** Choose What Makes Sense

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Person calmly closes phone and reaches for brush. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Choose What Makes Sense”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Rapid trend cards flash then freeze; on-screen title “Trend or Thoughtful Habit?”. 00:03–00:07: Shot of simple personal comb and towel; overlay “Trends Move Fast”. 00:07–00:10: Text: Choose thoughtfully; overlay “Choose What Makes Sense” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “A viral tip is not automatically a good habit. Ask what evidence supports it.”. END CTA: “Save this thought”.

**Suggested caption:** The Difference Between a Habit and a Hype — A viral tip is not automatically a good habit. Ask what evidence supports it. Save this thought. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not show fake trend endorsements. **Source IDs:** BRAND,AAD

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 35 — 2026-11-13 — A Letter to the First Circle
**Week 5 / RAKA story, standards & considered living**  |  **SEO query hypothesis:** join RAKA First Circle Pakistan  |  **CTA:** Join First Circle

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Sealed black letter with gold wax-like circle, not branded packaging. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Before You See the Products”. Optional small overlay: “Join First Circle”.

**Carousel slide 1 — Overlay:** Before You See the Products

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Sealed black letter with gold wax-like circle, not branded packaging. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Before You See the Products”.

**Carousel slide 2 — Overlay:** We Want to Hear You

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open blank handwritten-style letter on cream paper. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “We Want to Hear You”.

**Carousel slide 3 — Overlay:** Share Your Hair-Care Questions

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Simple message bubbles as abstract gold outlines. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Share Your Hair-Care Questions”.

**Carousel slide 4 — Overlay:** The First Circle Awaits

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gold-lit doorway fading into soft black. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “The First Circle Awaits”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Envelope slowly opens; on-screen title “Before You See the Products”. 00:03–00:07: Abstract message bubbles rise into frame; overlay “We Want to Hear You”. 00:07–00:10: Invitation text: raka.pk/first-circle; overlay “The First Circle Awaits” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Before the reveal, we want to understand what matters to your routine.”. END CTA: “Join First Circle”.

**Suggested caption:** A Letter to the First Circle — Before the reveal, we want to understand what matters to your routine. Join First Circle. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No promised private consultation or product result. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 36 — 2026-11-14 — Can Food Choices Affect Hair Health?
**Week 6 / Community questions, nutrition & myths**  |  **SEO query hypothesis:** diet and hair health Pakistan  |  **CTA:** Save the meal reminder

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Pakistani family table with dal, roti, seasonal greens and fruit. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Hair Care Is Bigger Than a Bathroom Shelf”. Optional small overlay: “Save the meal reminder”.

**Carousel slide 1 — Overlay:** Hair Care Is Bigger Than a Bathroom Shelf

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Pakistani family table with dal, roti, seasonal greens and fruit. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Care Is Bigger Than a Bathroom Shelf”.

**Carousel slide 2 — Overlay:** Protein Matters in a Balanced Diet

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Simple cooked lentils, eggs and beans in ceramic bowls. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Protein Matters in a Balanced Diet”.

**Carousel slide 3 — Overlay:** So Does Dietary Variety

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Colorful local vegetables and whole foods on black backdrop. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “So Does Dietary Variety”.

**Carousel slide 4 — Overlay:** No Single Meal Is a Cure

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Quiet balanced thali-style meal with negative space. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “No Single Meal Is a Cure”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Balanced Pakistani table appears; on-screen title “Hair Care Is Bigger Than a Bathroom Shelf”. 00:03–00:07: Three dishes highlighted in quick closeups; overlay “Protein Matters in a Balanced Diet”. 00:07–00:10: Text: Variety over miracle foods; overlay “No Single Meal Is a Cure” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Good nutrition supports general health. No single food guarantees thicker or faster-growing hair.”. END CTA: “Save the meal reminder”.

**Suggested caption:** Can Food Choices Affect Hair Health? — Good nutrition supports general health. No single food guarantees thicker or faster-growing hair. Save the meal reminder. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No medical nutrition plan or claims any food regrows hair. **Source IDs:** NUTRI,PAKNUT

**Supporting references:** AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips; UNICEF Pakistan: National Nutrition Survey 2018 — https://www.unicef.org/pakistan/national-nutrition-survey-2018

---

## DAY 37 — 2026-11-15 — The Junk Food Question
**Week 6 / Community questions, nutrition & myths**  |  **SEO query hypothesis:** junk food hair loss myths  |  **CTA:** Share the myth-buster

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Tasteful overhead burger and fries in clean editorial food photography. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Does One Burger Cause Hair Fall?”. Optional small overlay: “Share the myth-buster”.

**Carousel slide 1 — Overlay:** Does One Burger Cause Hair Fall?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Tasteful overhead burger and fries in clean editorial food photography. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Does One Burger Cause Hair Fall?”.

**Carousel slide 2 — Overlay:** No Single Food Explains Hair Loss

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Burger shifts beside colorful everyday home-cooked meal. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “No Single Food Explains Hair Loss”.

**Carousel slide 3 — Overlay:** Look at Your Usual Pattern

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Weekly plate icons illustrating dietary variety, no numeric prescriptions. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Look at Your Usual Pattern”.

**Carousel slide 4 — Overlay:** Food Guilt Is Not Hair Care

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Confident young adult enjoying varied foods at table. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Food Guilt Is Not Hair Care”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Burger enters with a question mark; on-screen title “Does One Burger Cause Hair Fall?”. 00:03–00:07: Cut to colorful Pakistani dinner plate; overlay “No Single Food Explains Hair Loss”. 00:07–00:10: Text: Think patterns, not one meal; overlay “Food Guilt Is Not Hair Care” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “A burger does not automatically cause hair loss. Your overall food pattern matters more.”. END CTA: “Share the myth-buster”.

**Suggested caption:** The Junk Food Question — A burger does not automatically cause hair loss. Your overall food pattern matters more. Share the myth-buster. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid food shaming, restrictive diet advice and causal junk-food claims. **Source IDs:** NUTRI

**Supporting references:** AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips

---

## DAY 38 — 2026-11-16 — Does Broiler Chicken Cause Hair Fall?
**Week 6 / Community questions, nutrition & myths**  |  **SEO query hypothesis:** broiler chicken hormones hair loss myth Pakistan  |  **CTA:** Save the fact check

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Cooked chicken curry in elegant ceramic dish, not raw chicken. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Chicken and Hair Loss: A Myth Check”. Optional small overlay: “Save the fact check”.

**Carousel slide 1 — Overlay:** Chicken and Hair Loss: A Myth Check

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Cooked chicken curry in elegant ceramic dish, not raw chicken. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Chicken and Hair Loss: A Myth Check”.

**Carousel slide 2 — Overlay:** Hormone Rumours Need Evidence

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Abstract question marks with a neutral paper document, no fake lab. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Hormone Rumours Need Evidence”.

**Carousel slide 3 — Overlay:** Protein Is Part of Ordinary Nutrition

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Balanced plate with chicken, dal and seasonal vegetables. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Protein Is Part of Ordinary Nutrition”.

**Carousel slide 4 — Overlay:** Avoid Unproven Food Fears

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Person serving a normal family meal without distress. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Avoid Unproven Food Fears”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Chicken meal on table with on-screen question; on-screen title “Chicken and Hair Loss: A Myth Check”. 00:03–00:07: Question mark resolves into “No proven link”; overlay “Hormone Rumours Need Evidence”. 00:07–00:10: Text: Don’t share rumours; overlay “Avoid Unproven Food Fears” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “There is no sound evidence that ordinary broiler chicken causes hair loss from added growth hormones.”. END CTA: “Save the fact check”.

**Suggested caption:** Does Broiler Chicken Cause Hair Fall? — There is no sound evidence that ordinary broiler chicken causes hair loss from added growth hormones. Save the fact check. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not imply all poultry from all sources has been safety-tested. **Source IDs:** UVAS,NUTRI

**Supporting references:** University of Veterinary and Animal Sciences: Poultry myths — https://www.uvas.edu.pk/advisory_service/PAS/faqs.php; AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips

---

## DAY 39 — 2026-11-17 — Could Skipping Meals Affect Your Hair?
**Week 6 / Community questions, nutrition & myths**  |  **SEO query hypothesis:** low calorie diet hair shedding  |  **CTA:** Save for later

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Minimal breakfast place-setting with fruit, eggs and roti. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your Body Needs Enough Food”. Optional small overlay: “Save for later”.

**Carousel slide 1 — Overlay:** Your Body Needs Enough Food

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal breakfast place-setting with fruit, eggs and roti. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your Body Needs Enough Food”.

**Carousel slide 2 — Overlay:** Very Restrictive Eating Can Matter

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Empty plate juxtaposed with simple balanced meal, no body-size imagery. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Very Restrictive Eating Can Matter”.

**Carousel slide 3 — Overlay:** Consistency and Variety Count

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Notebook planning regular meals beside vegetables. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Consistency and Variety Count”.

**Carousel slide 4 — Overlay:** Skip Extreme Food Rules

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Comforting shared lunch table scene. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Skip Extreme Food Rules”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Empty plate slowly fills with everyday foods; on-screen title “Your Body Needs Enough Food”. 00:03–00:07: Quick cut balanced lunch and evening meal; overlay “Very Restrictive Eating Can Matter”. 00:07–00:10: Text: Nourish, don’t punish; overlay “Skip Extreme Food Rules” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Very restrictive eating can affect hair and general well-being. Aim for variety, not extremes.”. END CTA: “Save for later”.

**Suggested caption:** Could Skipping Meals Affect Your Hair? — Very restrictive eating can affect hair and general well-being. Aim for variety, not extremes. Save for later. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not prescribe calorie amounts or imply guilt over eating habits. **Source IDs:** NUTRI

**Supporting references:** AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips

---

## DAY 40 — 2026-11-18 — Which Hair Myth Did You Grow Up With?
**Week 6 / Community questions, nutrition & myths**  |  **SEO query hypothesis:** hair oil myths Pakistan  |  **CTA:** Comment one myth

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Two Pakistani generations sitting together sharing an ordinary conversation. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “What Did You Hear Growing Up?”. Optional small overlay: “Comment one myth”.

**Carousel slide 1 — Overlay:** What Did You Hear Growing Up?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two Pakistani generations sitting together sharing an ordinary conversation. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “What Did You Hear Growing Up?”.

**Carousel slide 2 — Overlay:** More Oil Is Always Better?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Unbranded abstract golden droplet illustration, not real product. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “More Oil Is Always Better?”.

**Carousel slide 3 — Overlay:** Never Cut Hair?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Clean salon scissors laying flat near loose hair strands, no cutting scene. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Never Cut Hair?”.

**Carousel slide 4 — Overlay:** Let’s Question the Claims

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Playful minimalist question marks on charcoal. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Let’s Question the Claims”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Person reacts thoughtfully to a family tip; on-screen title “What Did You Hear Growing Up?”. 00:03–00:07: Two floating question cards appear; overlay “More Oil Is Always Better?”. 00:07–00:10: Text: What myth should RAKA check?; overlay “Let’s Question the Claims” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Every family has a hair-care tip. Which one should we look at more carefully?”. END CTA: “Comment one myth”.

**Suggested caption:** Which Hair Myth Did You Grow Up With? — Every family has a hair-care tip. Which one should we look at more carefully? Comment one myth. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not affirm a myth just because audience suggests it. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 41 — 2026-11-19 — Shared Brush, Shared Questions
**Week 6 / Community questions, nutrition & myths**  |  **SEO query hypothesis:** sharing combs hygiene children adults  |  **CTA:** Send to your flatmate

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Two roommates by a dresser with brushes, warm candid mood. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Would You Share Your Brush?”. Optional small overlay: “Send to your flatmate”.

**Carousel slide 1 — Overlay:** Would You Share Your Brush?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two roommates by a dresser with brushes, warm candid mood. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Would You Share Your Brush?”.

**Carousel slide 2 — Overlay:** Hair Tools Are Personal

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two separate combs against contrasting cream and charcoal. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Tools Are Personal”.

**Carousel slide 3 — Overlay:** Keep Them Clean

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hand gently removes captured hair from own brush. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Keep Them Clean”.

**Carousel slide 4 — Overlay:** Keep Them Separate

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Organized drawers with individual hair tools. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Keep Them Separate”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Hand reaches for shared brush then pauses; on-screen title “Would You Share Your Brush?”. 00:03–00:07: Two brushes placed in separate drawers; overlay “Hair Tools Are Personal”. 00:07–00:10: Text: Small hygiene choice; overlay “Keep Them Separate” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Separate brushes are a simple everyday hygiene habit, especially in shared spaces.”. END CTA: “Send to your flatmate”.

**Suggested caption:** Shared Brush, Shared Questions — Separate brushes are a simple everyday hygiene habit, especially in shared spaces. Send to your flatmate. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No alarmism about automatic infection from one-time sharing. **Source IDs:** CDC

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html

---

## DAY 42 — 2026-11-20 — Community Questions, Answered Simply
**Week 6 / Community questions, nutrition & myths**  |  **SEO query hypothesis:** Pakistan hair care FAQ  |  **CTA:** Send a question or join

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Three blank elegant message bubbles floating on black. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “You Asked. We Listened.”. Optional small overlay: “Send a question or join”.

**Carousel slide 1 — Overlay:** You Asked. We Listened.

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Three blank elegant message bubbles floating on black. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “You Asked. We Listened.”.

**Carousel slide 2 — Overlay:** Why Does Hair Feel Dry?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Macro of natural hair strands under soft dry air and daylight. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Why Does Hair Feel Dry?”.

**Carousel slide 3 — Overlay:** Should I Share My Comb?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single brush on cream background with split path icons. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Should I Share My Comb?”.

**Carousel slide 4 — Overlay:** More Useful Questions Ahead

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gold circular invitation frame with space for overlay text. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “More Useful Questions Ahead”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Three audience question bubbles pop in; on-screen title “You Asked. We Listened.”. 00:03–00:07: Cut to gentle hair scene and personal brush; overlay “Why Does Hair Feel Dry?”. 00:07–00:10: RAKA First Circle invitation appears; overlay “More Useful Questions Ahead” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “We are collecting everyday questions and turning them into clear, practical hair-care content.”. END CTA: “Send a question or join”.

**Suggested caption:** Community Questions, Answered Simply — We are collecting everyday questions and turning them into clear, practical hair-care content. Send a question or join. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Avoid public answers to personal medical symptoms. **Source IDs:** CDC,AAD,BRAND

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 43 — 2026-11-21 — Two Priorities. One Thoughtful Brand.
**Week 7 / Two care priorities & informed choices**  |  **SEO query hypothesis:** RAKA hair fall control scalp hair growth treatment  |  **CTA:** Join First Circle

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Two glowing slender gold arcs separate on matte black, no bottle silhouettes. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Two Areas of Focus”. Optional small overlay: “Join First Circle”.

**Carousel slide 1 — Overlay:** Two Areas of Focus

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two glowing slender gold arcs separate on matte black, no bottle silhouettes. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Two Areas of Focus”.

**Carousel slide 2 — Overlay:** Hair Fall Control

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gentle hairbrush and natural dark strands as a non-treatment context. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Fall Control”.

**Carousel slide 3 — Overlay:** Scalp & Hair Growth Care

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Close crop natural scalp part and hair texture. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Scalp & Hair Growth Care”.

**Carousel slide 4 — Overlay:** Discover the Thinking First

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two minimalist gold circles converge over mountain contour. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Discover the Thinking First”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Two gold lines split into two thematic paths; on-screen title “Two Areas of Focus”. 00:03–00:07: Brush and scalp macro alternate; overlay “Hair Fall Control”. 00:07–00:10: Text: Two care priorities, RAKA; overlay “Discover the Thinking First” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “RAKA is preparing two focused hair-care products. Learn the differences before the reveal.”. END CTA: “Join First Circle”.

**Suggested caption:** Two Priorities. One Thoughtful Brand. — RAKA is preparing two focused hair-care products. Learn the differences before the reveal. Join First Circle. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Product names are categories, not verified treatment outcomes. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 44 — 2026-11-22 — What Does Hair Fall Control Really Mean?
**Week 7 / Two care priorities & informed choices**  |  **SEO query hypothesis:** hair fall control expectations  |  **CTA:** Save this distinction

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Editorial text canvas and single long hair strand. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Words Matter: Hair Fall Control”. Optional small overlay: “Save this distinction”.

**Carousel slide 1 — Overlay:** Words Matter: Hair Fall Control

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Editorial text canvas and single long hair strand. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Words Matter: Hair Fall Control”.

**Carousel slide 2 — Overlay:** Breakage and Shedding Differ

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Split macro of short snapped fiber and natural long shed fiber. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Breakage and Shedding Differ”.

**Carousel slide 3 — Overlay:** Causes Can Be Different

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Diverse hair portraits in balanced four-panel editorial grid. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Causes Can Be Different”.

**Carousel slide 4 — Overlay:** Know the Limits of Claims

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Simple gold underline below blank fact-check card. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Know the Limits of Claims”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Phrase Hair Fall Control appears as text overlay; on-screen title “Words Matter: Hair Fall Control”. 00:03–00:07: Strand breakage and shedding comparison; overlay “Breakage and Shedding Differ”. 00:07–00:10: Text: Ask what each claim means; overlay “Know the Limits of Claims” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Hair-fall concerns have different possible causes. A product name alone cannot explain them.”. END CTA: “Save this distinction”.

**Suggested caption:** What Does Hair Fall Control Really Mean? — Hair-fall concerns have different possible causes. A product name alone cannot explain them. Save this distinction. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Never promise prevention or regrowth from RAKA oils. **Source IDs:** NUTRI,DAMAGE

**Supporting references:** AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips; AAD: How to stop damaging your hair — https://www.aad.org/public/diseases/hair-loss/insider/stop-damage

---

## DAY 45 — 2026-11-23 — Scalp Care Is Not the Same as Hair Growth
**Week 7 / Two care priorities & informed choices**  |  **SEO query hypothesis:** scalp care vs hair growth  |  **CTA:** Join to learn more

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Scalp part and hair strand separated by negative space. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Scalp Care ≠ Guaranteed Growth”. Optional small overlay: “Join to learn more”.

**Carousel slide 1 — Overlay:** Scalp Care ≠ Guaranteed Growth

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Scalp part and hair strand separated by negative space. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Scalp Care ≠ Guaranteed Growth”.

**Carousel slide 2 — Overlay:** Hygiene Is One Part

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Personal clean brush and gentle towel in minimal scene. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Hygiene Is One Part”.

**Carousel slide 3 — Overlay:** Growth Is More Complex

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Conceptual hair-cycle arcs and question marks, not literal medical anatomy. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Growth Is More Complex”.

**Carousel slide 4 — Overlay:** Understanding Comes First

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Portrait in natural light with thoughtful gaze. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Understanding Comes First”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Scalp shot and hair strand alternate; on-screen title “Scalp Care ≠ Guaranteed Growth”. 00:03–00:07: Gold line divides two terms; overlay “Hygiene Is One Part”. 00:07–00:10: Text: Care is not a guarantee; overlay “Understanding Comes First” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “A thoughtful scalp routine is useful. It does not guarantee hair growth or regrowth.”. END CTA: “Join to learn more”.

**Suggested caption:** Scalp Care Is Not the Same as Hair Growth — A thoughtful scalp routine is useful. It does not guarantee hair growth or regrowth. Join to learn more. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No mechanism claims for formula or follicles. **Source IDs:** CDC,NUTRI,BRAND

**Supporting references:** CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips

---

## DAY 46 — 2026-11-24 — Lightweight Is a Sensory Goal, Not a Treatment Claim
**Week 7 / Two care priorities & informed choices**  |  **SEO query hypothesis:** non greasy hair oil expectations  |  **CTA:** Vote in First Circle

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Flowing dark silk ribbon over stone, no oils or bottles. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “How Should Hair Care Feel?”. Optional small overlay: “Vote in First Circle”.

**Carousel slide 1 — Overlay:** How Should Hair Care Feel?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Flowing dark silk ribbon over stone, no oils or bottles. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “How Should Hair Care Feel?”.

**Carousel slide 2 — Overlay:** Texture Is Personal

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two hair textures gliding across a cream background. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Texture Is Personal”.

**Carousel slide 3 — Overlay:** Comfort Matters

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Woman with loose natural hair outdoors soft wind, no touch of product. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Comfort Matters”.

**Carousel slide 4 — Overlay:** Ask About Product Experience

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal open-ended survey card with clean gold border. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Ask About Product Experience”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Silk floats across frame; on-screen title “How Should Hair Care Feel?”. 00:03–00:07: Cut to two natural hair textures; overlay “Texture Is Personal”. 00:07–00:10: Text: Tell us what you prefer; overlay “Ask About Product Experience” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “When choosing hair care, how it feels matters too. What texture do you usually prefer?”. END CTA: “Vote in First Circle”.

**Suggested caption:** Lightweight Is a Sensory Goal, Not a Treatment Claim — When choosing hair care, how it feels matters too. What texture do you usually prefer? Vote in First Circle. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not claim RAKA formula non-greasy without finished-product testing. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 47 — 2026-11-25 — Five Questions Before Choosing Hair Oil
**Week 7 / Two care priorities & informed choices**  |  **SEO query hypothesis:** how to choose hair oil Pakistan  |  **CTA:** Download the guide

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Blank editorial checklist with gold tick marks and no product imagery. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Before Choosing an Oil…”. Optional small overlay: “Download the guide”.

**Carousel slide 1 — Overlay:** Before Choosing an Oil…

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Blank editorial checklist with gold tick marks and no product imagery. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Before Choosing an Oil…”.

**Carousel slide 2 — Overlay:** What Is Your Hair Type?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Three different hair textures with consistent lighting. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “What Is Your Hair Type?”.

**Carousel slide 3 — Overlay:** What Does the Label Actually Say?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Abstract generic sheet of ingredients text represented as unreadable lines, no bottle. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “What Does the Label Actually Say?”.

**Carousel slide 4 — Overlay:** Can You Use It Comfortably?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Neutral portrait considering a routine at vanity, no products. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Can You Use It Comfortably?”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Five checklist markers appear one after another; on-screen title “Before Choosing an Oil…”. 00:03–00:07: Hair textures and generic information sheet; overlay “What Is Your Hair Type?”. 00:07–00:10: Text: Ask better questions; overlay “Can You Use It Comfortably?” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Check your needs, the information given, and your preferences before choosing any hair product.”. END CTA: “Download the guide”.

**Suggested caption:** Five Questions Before Choosing Hair Oil — Check your needs, the information given, and your preferences before choosing any hair product. Download the guide. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not offer ingredients or patch-test guarantee not appropriate to specific formula. **Source IDs:** AAD,BRAND

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 48 — 2026-11-26 — What Hair-Care Concern Matters Most?
**Week 7 / Two care priorities & informed choices**  |  **SEO query hypothesis:** hair fall dry scalp breakage survey  |  **CTA:** Vote at raka.pk/first-circle

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Four square abstract theme cards in black and cream. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “What Matters Most to You?”. Optional small overlay: “Vote at raka.pk/first-circle”.

**Carousel slide 1 — Overlay:** What Matters Most to You?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Four square abstract theme cards in black and cream. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “What Matters Most to You?”.

**Carousel slide 2 — Overlay:** Breakage or Dryness?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Split macro hair ends and airy dry-looking hair texture. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Breakage or Dryness?”.

**Carousel slide 3 — Overlay:** Scalp Comfort or Manageability?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Scalp part and wide-tooth comb closeups. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Scalp Comfort or Manageability?”.

**Carousel slide 4 — Overlay:** Help Shape Our Content

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Interactive phone poll mockup without readable tiny text. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Help Shape Our Content”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Four concerns appear as large labels; on-screen title “What Matters Most to You?”. 00:03–00:07: Finger taps a single non-medical poll option; overlay “Breakage or Dryness?”. 00:07–00:10: Text: Your voice shapes the lessons; overlay “Help Shape Our Content” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Tell us which everyday hair-care topic deserves more clear information.”. END CTA: “Vote at raka.pk/first-circle”.

**Suggested caption:** What Hair-Care Concern Matters Most? — Tell us which everyday hair-care topic deserves more clear information. Vote at raka.pk/first-circle. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not collect medical records or promise personalized diagnosis. **Source IDs:** BRAND,AAD

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips

---

## DAY 49 — 2026-11-27 — What RAKA Will and Won’t Promise
**Week 7 / Two care priorities & informed choices**  |  **SEO query hypothesis:** evidence led hair care Pakistan  |  **CTA:** Join the conversation

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Understated gold line on velvet black. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Clarity Is a Commitment”. Optional small overlay: “Join the conversation”.

**Carousel slide 1 — Overlay:** Clarity Is a Commitment

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Understated gold line on velvet black. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Clarity Is a Commitment”.

**Carousel slide 2 — Overlay:** We Will Explain What We Know

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open research journal and sunlight. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “We Will Explain What We Know”.

**Carousel slide 3 — Overlay:** We Will Name Uncertainty

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: An elegant question-mark shadow over paper. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “We Will Name Uncertainty”.

**Carousel slide 4 — Overlay:** We Will Respect Your Choice

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Confident portrait with natural hair, no retouching drama. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “We Will Respect Your Choice”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Minimal word Clarity overlays black; on-screen title “Clarity Is a Commitment”. 00:03–00:07: Journal turns page in cinematic macro; overlay “We Will Explain What We Know”. 00:07–00:10: Text: Knowledge before claims; overlay “We Will Respect Your Choice” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “You deserve clear information and realistic expectations. That is the standard RAKA wants to uphold.”. END CTA: “Join the conversation”.

**Suggested caption:** What RAKA Will and Won’t Promise — You deserve clear information and realistic expectations. That is the standard RAKA wants to uphold. Join the conversation. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not suggest official clinical accreditation or results. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 50 — 2026-11-28 — Your Invitation to RAKA First Circle
**Week 8 / First Circle, guide & registration**  |  **SEO query hypothesis:** RAKA First Circle signup  |  **CTA:** Register for free

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Architectural gold ring of light on deep black. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “First Circle Is Open”. Optional small overlay: “Register for free”.

**Carousel slide 1 — Overlay:** First Circle Is Open

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Architectural gold ring of light on deep black. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “First Circle Is Open”.

**Carousel slide 2 — Overlay:** Learn Before Launch

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Hand opening editorial hair-care journal in soft daylight. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Learn Before Launch”.

**Carousel slide 3 — Overlay:** Receive a Free 7-Day Guide

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Seven elegant paper cards with distinct gold edges and no bottles. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Receive a Free 7-Day Guide”.

**Carousel slide 4 — Overlay:** Sign Up at raka.pk/first-circle

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal gold doorway with carefully empty center for final URL overlay. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Sign Up at raka.pk/first-circle”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Gold ring grows from center; on-screen title “First Circle Is Open”. 00:03–00:07: Seven paper cards fan open; overlay “Learn Before Launch”. 00:07–00:10: Text: Join raka.pk/first-circle; overlay “Sign Up at raka.pk/first-circle” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Join RAKA First Circle for practical hair-care knowledge and launch updates you choose to receive.”. END CTA: “Register for free”.

**Suggested caption:** Your Invitation to RAKA First Circle — Join RAKA First Circle for practical hair-care knowledge and launch updates you choose to receive. Register for free. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No claims of exclusivity unless a real limitation exists. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 51 — 2026-11-29 — What Is Inside the Seven-Day Guide?
**Week 8 / First Circle, guide & registration**  |  **SEO query hypothesis:** free hair care guide Pakistan  |  **CTA:** Get the free guide

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Open cream booklet showing abstract lines and seven section tabs. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “A Guide to Everyday Hair Habits”. Optional small overlay: “Get the free guide”.

**Carousel slide 1 — Overlay:** A Guide to Everyday Hair Habits

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open cream booklet showing abstract lines and seven section tabs. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “A Guide to Everyday Hair Habits”.

**Carousel slide 2 — Overlay:** Gentle Washing and Drying

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fresh towel near simple sink with no cosmetics. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Gentle Washing and Drying”.

**Carousel slide 3 — Overlay:** Hair Tools and Styling

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Soft scrunchie and wide-tooth comb flat-lay. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Tools and Styling”.

**Carousel slide 4 — Overlay:** Balanced Habits

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Pakistani healthy-style family dinner table, no strict diet rules. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Balanced Habits”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Paper guide pages flip 1 to 7; on-screen title “A Guide to Everyday Hair Habits”. 00:03–00:07: Towel, brush and food scenes flicker softly; overlay “Gentle Washing and Drying”. 00:07–00:10: Text: Get the free guide; overlay “Balanced Habits” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “One small habit a day: washing, handling, and better questions for your routine.”. END CTA: “Get the free guide”.

**Suggested caption:** What Is Inside the Seven-Day Guide? — One small habit a day: washing, handling, and better questions for your routine. Get the free guide. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Guide is educational, not clinical or nutritional treatment. **Source IDs:** AAD,CDC,NUTRI

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips; CDC: Hair and Scalp Hygiene — https://www.cdc.gov/hygiene/about/hair-and-scalp-hygiene.html; AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips

---

## DAY 52 — 2026-11-30 — Why We Ask for Your Email
**Week 8 / First Circle, guide & registration**  |  **SEO query hypothesis:** RAKA First Circle email signup privacy  |  **CTA:** Register with control

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Single unopened cream envelope floating over charcoal. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Your Inbox. Your Choice.”. Optional small overlay: “Register with control”.

**Carousel slide 1 — Overlay:** Your Inbox. Your Choice.

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single unopened cream envelope floating over charcoal. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Your Inbox. Your Choice.”.

**Carousel slide 2 — Overlay:** A Welcome and Hair-Care Guide

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Neat printed guide pages next to envelope. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “A Welcome and Hair-Care Guide”.

**Carousel slide 3 — Overlay:** Updates Only with Permission

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Clean generic consent checkbox enlarged on abstract interface. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Updates Only with Permission”.

**Carousel slide 4 — Overlay:** Unsubscribe When You Want

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Elegant small door opening to daylight, no fear design. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Unsubscribe When You Want”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Envelope opens showing one paper guide; on-screen title “Your Inbox. Your Choice.”. 00:03–00:07: Checkbox appears unticked then optional check; overlay “A Welcome and Hair-Care Guide”. 00:07–00:10: Text: Your choice always; overlay “Unsubscribe When You Want” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Register for the guide. Choose separately whether you want launch emails or other updates.”. END CTA: “Register with control”.

**Suggested caption:** Why We Ask for Your Email — Register for the guide. Choose separately whether you want launch emails or other updates. Register with control. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not auto-enroll email/WhatsApp/SMS without proper permission. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 53 — 2026-12-01 — What Is an Early-Access Invitation?
**Week 8 / First Circle, guide & registration**  |  **SEO query hypothesis:** RAKA launch early access  |  **CTA:** Join for launch news

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Black-gold ticket-shaped light card, not a product label. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Early Access, Explained”. Optional small overlay: “Join for launch news”.

**Carousel slide 1 — Overlay:** Early Access, Explained

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Black-gold ticket-shaped light card, not a product label. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Early Access, Explained”.

**Carousel slide 2 — Overlay:** Be Notified of Launch Details

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal digital calendar with blank dates. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Be Notified of Launch Details”.

**Carousel slide 3 — Overlay:** Get the Information Before the Rush

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Empty elegant browser frame with text-free product section. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Get the Information Before the Rush”.

**Carousel slide 4 — Overlay:** Make Your Own Decision

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Smartphone showing blank premium registration interface. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Make Your Own Decision”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Calendar page turns toward launch week; on-screen title “Early Access, Explained”. 00:03–00:07: Notification bell line appears; overlay “Be Notified of Launch Details”. 00:07–00:10: Text: Learn first. Decide later.; overlay “Make Your Own Decision” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “First Circle members receive launch information directly. Joining never obliges you to buy.”. END CTA: “Join for launch news”.

**Suggested caption:** What Is an Early-Access Invitation? — First Circle members receive launch information directly. Joining never obliges you to buy. Join for launch news. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not promise advance stock, discounts or priority purchases unless operationally real. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 54 — 2026-12-02 — One Friend, One Useful Guide
**Week 8 / First Circle, guide & registration**  |  **SEO query hypothesis:** RAKA referral launch sharing  |  **CTA:** Copy your referral link

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Two friends talking naturally at a cafe, modest stylish fashion. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “Know Someone Who Loves Hair Care?”. Optional small overlay: “Copy your referral link”.

**Carousel slide 1 — Overlay:** Know Someone Who Loves Hair Care?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two friends talking naturally at a cafe, modest stylish fashion. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “Know Someone Who Loves Hair Care?”.

**Carousel slide 2 — Overlay:** Share Knowledge, Not Pressure

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: One cream informational card passed between two hands. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Share Knowledge, Not Pressure”.

**Carousel slide 3 — Overlay:** They Choose Whether to Join

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two simple mobile silhouettes connected by one thin gold line. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “They Choose Whether to Join”.

**Carousel slide 4 — Overlay:** Invite Thoughtfully

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: One gold invitation circle with airy typography space. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Invite Thoughtfully”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: One friend shares a phone link; on-screen title “Know Someone Who Loves Hair Care?”. 00:03–00:07: Second friend opens a clean guide cover; overlay “Share Knowledge, Not Pressure”. 00:07–00:10: Text: Share an invitation, not pressure; overlay “Invite Thoughtfully” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “If the guide would help a friend, invite them. They can choose to join on their terms.”. END CTA: “Copy your referral link”.

**Suggested caption:** One Friend, One Useful Guide — If the guide would help a friend, invite them. They can choose to join on their terms. Copy your referral link. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No reward promised unless referral tracking and terms live. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 55 — 2026-12-03 — A Few Things We Believe About Hair Care
**Week 8 / First Circle, guide & registration**  |  **SEO query hypothesis:** hair care myths and facts Pakistan  |  **CTA:** Save then join First Circle

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Five tiny gold dots arranged across black editorial frame. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “5 Things We Believe”. Optional small overlay: “Save then join First Circle”.

**Carousel slide 1 — Overlay:** 5 Things We Believe

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Five tiny gold dots arranged across black editorial frame. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “5 Things We Believe”.

**Carousel slide 2 — Overlay:** Routines Need Context

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Portraits of different natural hair types. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Routines Need Context”.

**Carousel slide 3 — Overlay:** No One Ingredient Does Everything

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Abstract botanical leaves and ordinary hair strands, no ingredient formula image. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “No One Ingredient Does Everything”.

**Carousel slide 4 — Overlay:** Good Information Is Part of Care

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Research notebook open beside hair comb. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Good Information Is Part of Care”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Five dots become three concise lesson cards; on-screen title “5 Things We Believe”. 00:03–00:07: Flashes of hair, comb, nutrition plate; overlay “Routines Need Context”. 00:07–00:10: Text: Realistic care. Real choices.; overlay “Good Information Is Part of Care” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Different hair, different routines. Care can help, but no single product answers every concern.”. END CTA: “Save then join First Circle”.

**Suggested caption:** A Few Things We Believe About Hair Care — Different hair, different routines. Care can help, but no single product answers every concern. Save then join First Circle. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not suggest botanicals can treat serious hair loss. **Source IDs:** AAD,NUTRI,BRAND

**Supporting references:** AAD: Tips for healthy hair — https://www.aad.org/public/everyday-care/hair-scalp-care/hair/healthy-hair-tips; AAD: Hair loss management and nutrition — https://www.aad.org/public/diseases/hair-loss/treatment/tips

---

## DAY 56 — 2026-12-04 — Your First Circle Questions Answered
**Week 8 / First Circle, guide & registration**  |  **SEO query hypothesis:** RAKA First Circle FAQs Pakistan  |  **CTA:** Read the FAQ and register

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Elegant phone showing generic confirmation tick. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “What Happens After Sign-Up?”. Optional small overlay: “Read the FAQ and register”.

**Carousel slide 1 — Overlay:** What Happens After Sign-Up?

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Elegant phone showing generic confirmation tick. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “What Happens After Sign-Up?”.

**Carousel slide 2 — Overlay:** You Receive the Free Guide

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Small cream booklet illuminated by soft daylight. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “You Receive the Free Guide”.

**Carousel slide 3 — Overlay:** You Control Marketing Preferences

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Three unticked channels drawn as minimalist empty checkboxes. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “You Control Marketing Preferences”.

**Carousel slide 4 — Overlay:** You Can Leave Anytime

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open minimalist gate in warm dawn light. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “You Can Leave Anytime”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Phone tick appears after submit; on-screen title “What Happens After Sign-Up?”. 00:03–00:07: Guide arrives as envelope animation; overlay “You Receive the Free Guide”. 00:07–00:10: Text: Consent. Control. Clarity.; overlay “You Can Leave Anytime” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Register, receive the guide, and choose what updates you want. Your preferences remain yours.”. END CTA: “Read the FAQ and register”.

**Suggested caption:** Your First Circle Questions Answered — Register, receive the guide, and choose what updates you want. Your preferences remain yours. Read the FAQ and register. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Make claims consistent with implemented opt-in flow and policies. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 57 — 2026-12-05 — Four Days to a New Chapter
**Week 9 / Final four-day countdown**  |  **SEO query hypothesis:** RAKA launch countdown 4 days  |  **CTA:** Join before launch

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Sculptural numeral four casting long gold shadow on black stone. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “4 DAYS”. Optional small overlay: “Join before launch”.

**Carousel slide 1 — Overlay:** 4 DAYS

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Sculptural numeral four casting long gold shadow on black stone. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “4 DAYS”.

**Carousel slide 2 — Overlay:** Built Around Better Questions

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Empty premium research notebook with gold edge lighting. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Built Around Better Questions”.

**Carousel slide 3 — Overlay:** Two Care Priorities

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Two separate luminous curved lines, never bottle-like silhouettes. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Two Care Priorities”.

**Carousel slide 4 — Overlay:** First Circle Is Still Open

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Architectural gold entryway and empty centered CTA area. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “First Circle Is Still Open”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Gold 4 appears from darkness; on-screen title “4 DAYS”. 00:03–00:07: Two thin arcs form a quiet visual rhythm; overlay “Built Around Better Questions”. 00:07–00:10: Text: First Circle / raka.pk; overlay “First Circle Is Still Open” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Four days to the RAKA launch. Two care priorities. One invitation to learn more.”. END CTA: “Join before launch”.

**Suggested caption:** Four Days to a New Chapter — Four days to the RAKA launch. Two care priorities. One invitation to learn more. Join before launch. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Verify date before scheduling and avoid fake scarcity. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 58 — 2026-12-06 — Three Days. One Clear Idea.
**Week 9 / Final four-day countdown**  |  **SEO query hypothesis:** RAKA launch countdown 3 days  |  **CTA:** Register for updates

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Large gold numeral three shaped by soft mountain shadow on black. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “3 DAYS”. Optional small overlay: “Register for updates”.

**Carousel slide 1 — Overlay:** 3 DAYS

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Large gold numeral three shaped by soft mountain shadow on black. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “3 DAYS”.

**Carousel slide 2 — Overlay:** Knowledge Before Hype

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Open abstract clean notebook and softly lit hair strand. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Knowledge Before Hype”.

**Carousel slide 3 — Overlay:** Care Without Guarantees

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Natural hair moving in soft air, no cosmetic editing. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Care Without Guarantees”.

**Carousel slide 4 — Overlay:** Get Launch Details First

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gold line enclosing typed URL space on cream backdrop. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “Get Launch Details First”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Gold 3 rotates slightly under light; on-screen title “3 DAYS”. 00:03–00:07: Hair and knowledge scenes crossfade; overlay “Knowledge Before Hype”. 00:07–00:10: Text: Learn before the reveal; overlay “Get Launch Details First” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Three days left. Our message stays the same: thoughtful care begins with understanding.”. END CTA: “Register for updates”.

**Suggested caption:** Three Days. One Clear Idea. — Three days left. Our message stays the same: thoughtful care begins with understanding. Register for updates. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** No claim any product prevents or reverses hair loss. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 59 — 2026-12-07 — Two Days. Two Focus Areas.
**Week 9 / Final four-day countdown**  |  **SEO query hypothesis:** RAKA two hair oils release  |  **CTA:** Join for product details

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Minimal metal-like numeral two, no bottle/packaging shape. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “2 DAYS”. Optional small overlay: “Join for product details”.

**Carousel slide 1 — Overlay:** 2 DAYS

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Minimal metal-like numeral two, no bottle/packaging shape. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “2 DAYS”.

**Carousel slide 2 — Overlay:** Hair Fall Control Treatment Oil

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Fine outline of a comb and a strand beside editorial gold title area. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “Hair Fall Control Treatment Oil”.

**Carousel slide 3 — Overlay:** Scalp & Hair Growth Treatment Oil

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Scalp-hair texture macro with separate gold title area. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “Scalp & Hair Growth Treatment Oil”.

**Carousel slide 4 — Overlay:** See the Details at Launch

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Dark mountain gradient and empty website CTA. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “See the Details at Launch”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Two curved light trails draw number 2; on-screen title “2 DAYS”. 00:03–00:07: Text-only treatment names alternate; overlay “Hair Fall Control Treatment Oil”. 00:07–00:10: Text: Full details at launch; overlay “See the Details at Launch” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Two focus areas, with full product information coming on launch day.”. END CTA: “Join for product details”.

**Suggested caption:** Two Days. Two Focus Areas. — Two focus areas, with full product information coming on launch day. Join for product details. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Treatment names are product names, not medical evidence of effect. **Source IDs:** BRAND

**Supporting references:** 

---

## DAY 60 — 2026-12-08 — Tomorrow, Meet RAKA
**Week 9 / Final four-day countdown**  |  **SEO query hypothesis:** RAKA launch tomorrow  |  **CTA:** Last pre-launch registration

**Single-feed visual prompt**

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SINGLE-FEED-POST COMPOSITION: Single gold sunrise arc above black horizon. Keep space for 2-line headline and small RAKA wordmark. Editorial overlaid headline: “TOMORROW”. Optional small overlay: “Last pre-launch registration”.

**Carousel slide 1 — Overlay:** TOMORROW

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Single gold sunrise arc above black horizon. Slide 1 of four. OVERLAY COPY (add manually, not generated inside image): “TOMORROW”.

**Carousel slide 2 — Overlay:** The Questions Led Us Here

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Montage grid of hair textures, clean towel and city window. Slide 2 of four. OVERLAY COPY (add manually, not generated inside image): “The Questions Led Us Here”.

**Carousel slide 3 — Overlay:** The Collection Comes Next

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Gold curtain of light with no objects or silhouettes behind. Slide 3 of four. OVERLAY COPY (add manually, not generated inside image): “The Collection Comes Next”.

**Carousel slide 4 — Overlay:** raka.pk / First Circle

Produce ONE 1080×1350 portrait editorial social-media image (4:5) for RAKA First Circle; premium Pakistani hair-care education campaign, near-black #11100F, champagne gold #C5A46B, warm ivory #F3EDE1, naturally lit realism, refined layout, ample blank negative space in upper 25% for human-added copy, visually diverse contemporary Pakistani adult models when people are needed, authentic clothing and locations, sensitive scalp/hair close-ups depicted respectfully. Photograph or editorial diagram only as the concept requests. Do NOT render written text, logos, watermarks, product bottles, cosmetic packaging, oil droppers, jars, fake scientific micrographs, before/after comparisons or sensational hair loss imagery. Brand logo and headline are layered in design software afterward. SCENE: Final minimal open circular gold invitation mark. Slide 4 of four. OVERLAY COPY (add manually, not generated inside image): “raka.pk / First Circle”.

**10-second video prompt**

Create one original 10.0-second vertical 1080×1920 (9:16), 24fps premium RAKA social video. Cinematic, sophisticated contemporary Pakistan, matte charcoal, champagne-gold light, natural hair texture, realistic people, three clear visual beats with restrained camera movement and coherent match cuts. Keep all crucial visuals centered within 80% safe area. No product imagery, bottles, packaging, jars, oil pours, false clinical imagery, watermarks or AI-generated lettering. Add legible on-screen typography, RAKA logo, subtitles and link as separate motion-graphics layers in editing. Soft licensed ambient music at low volume, natural sound accents; voiceover spoken calmly, approximately 2.2–2.5 words per second. TIMELINE 00:00–00:03: Sunrise light sweeps across black; on-screen title “TOMORROW”. 00:03–00:07: Fast montage hair, city, comb, community; overlay “The Questions Led Us Here”. 00:07–00:10: RAKA logo and launch tomorrow text; overlay “raka.pk / First Circle” + subtle RAKA logo. VOICEOVER (read in 10 seconds): “Tomorrow, RAKA begins its next chapter. Learn the details when the collection is revealed.”. END CTA: “Last pre-launch registration”.

**Suggested caption:** Tomorrow, Meet RAKA — Tomorrow, RAKA begins its next chapter. Learn the details when the collection is revealed. Last pre-launch registration. Learn more with RAKA First Circle at raka.pk/first-circle.

**Editorial check:** Do not reveal product images or imply limited supply. **Source IDs:** BRAND

**Supporting references:** 

---

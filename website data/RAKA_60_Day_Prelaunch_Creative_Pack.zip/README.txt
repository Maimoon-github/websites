RAKA FIRST CIRCLE — 60-DAY ORGANIC CONTENT PRODUCTION PACK
Pakistan | 10 October to 8 December 2026 | No product reveal

CONTENTS
1. RAKA_60_Day_Creative_Calendar.xlsx
   - Overview KPI/status dashboard
   - 60-Day Calendar (60 daily records)
   - 240 Carousel Slides (copy/paste each standalone image-generation prompt)
   - 60 Video Prompts (three timed shots and complete 10-second prompts)
   - Evidence & Guardrails (sources and editorial restrictions)

2. RAKA_60_Day_Production_Bible.md
   - All 60 days written in a readable long-form format
   - 60 standalone static visual prompts
   - 240 carousel slide-by-slide prompts
   - 60 timed video prompts + voiceovers
   - Captions, search-intent hypotheses, references and claim checks

3. RAKA_60_Day_Prompts.json
   - Structured data for creative automation or ingestion into a scheduling platform

WORKFLOW
- Verify research links and final caption facts before publishing.
- Generate visual backgrounds; apply all text, RAKA logo and captions in your design app.
- Keep 4:5 images at 1080 x 1350 and video at 9:16 / 1080 x 1920, exactly 10 seconds.
- Check sound/music licensing, visual authenticity, and cross-platform safe areas.
- Review voiceover speed; all written VO scripts have approximately 8-17 words.
- Publish responsibly and track qualified visits to raka.pk/first-circle.

EVIDENCE / CLAIMS
- No dermatological or medical advice. No diagnosis, cure, guarantee or promise.
- Pollution research does not prove that smog directly caused a given person's hair loss.
- Hard-water research is mixed; do not say all Pakistani tap water causes hair loss.
- Ordinary broiler chicken should not be depicted as a proven hair-loss cause.
- One fast-food meal does not cause hair loss.
- Traffic noise can affect rest and well-being; direct hair-loss causation is unproven.
- Do not disclose RAKA product images, packaging, formula or make product efficacy claims.
